"""
Per-domain MariaDB database provisioning.

Unlike the login-style credentials elsewhere in this app (admin, mail,
FTP - all stored as one-way hashes), a database password has to be
handed back to the customer to paste into their application's config
file, so it's stored retrievably here, in hostpanel.db, which is
root-readable only (mode 600, set by the installer). That's a
deliberate, narrower exception to "never store secrets in plaintext" -
worth knowing about if you're auditing this file.

Connects to MariaDB as root via the local Unix socket, using the
root password the Stage 1 installer generated and saved to
DB_ROOT_PASSWORD_FILE (root-readable only). Every identifier that ends
up interpolated into raw SQL (database name, username) is validated
against a strict whitelist regex first - MySQL/MariaDB don't support
parameterized identifiers, so this validation is the only thing
standing between a bad label and SQL injection into an admin-level
connection.
"""
import os
import re
import secrets
import contextlib
from . import config, db, security

IDENT_RE = re.compile(r"^[a-z][a-z0-9_]{0,63}$")


class DatabaseError(Exception):
    pass


def _root_connection():
    try:
        import pymysql
    except ImportError as e:
        raise DatabaseError("pymysql is not installed - run installer/install_stage3.sh") from e

    if not os.path.exists(config.DB_ROOT_PASSWORD_FILE):
        raise DatabaseError(f"MariaDB root password file not found at {config.DB_ROOT_PASSWORD_FILE}")
    with open(config.DB_ROOT_PASSWORD_FILE) as f:
        root_password = f.read().strip()

    return pymysql.connect(
        unix_socket=config.MYSQL_SOCKET,
        user="root",
        password=root_password,
        autocommit=True,
        connect_timeout=5,
    )


def _validate_identifier(value: str, max_len: int, kind: str) -> str:
    value = value.strip().lower()
    if len(value) > max_len or not IDENT_RE.match(value):
        raise DatabaseError(
            f"'{value}' is not a valid {kind} - use lowercase letters, numbers, and underscores, "
            f"starting with a letter, {max_len} characters max"
        )
    return value


def list_databases(domain: str):
    with contextlib.closing(db.get_conn()) as conn:
        return conn.execute("SELECT * FROM databases WHERE domain=? ORDER BY created_at", (domain,)).fetchall()


def create_database(domain: str, label: str, actor: str = "admin") -> dict:
    domain = security.validate_domain(domain)
    linux_user = security._get_linux_user(domain)

    label = re.sub(r"[^a-z0-9_]", "", label.strip().lower())
    if not label:
        raise DatabaseError("Give the database a label (letters, numbers, underscores)")

    db_name = _validate_identifier(f"{linux_user}_{label}"[: config.DB_NAME_MAX_LEN], config.DB_NAME_MAX_LEN, "database name")
    db_user = _validate_identifier(
        (f"{linux_user}_{label}"[:24] + "_" + secrets.token_hex(3))[: config.DB_USER_MAX_LEN],
        config.DB_USER_MAX_LEN, "database username",
    )
    db_password = secrets.token_urlsafe(18)

    with contextlib.closing(db.get_conn()) as conn:
        count = conn.execute("SELECT COUNT(*) c FROM databases WHERE domain=?", (domain,)).fetchone()["c"]
        if count >= config.MAX_DATABASES_PER_DOMAIN:
            raise DatabaseError(f"Database limit reached for {domain}")
        if conn.execute("SELECT 1 FROM databases WHERE db_name=?", (db_name,)).fetchone():
            raise DatabaseError(f"A database named '{db_name}' already exists - try a different label")

    conn = _root_connection()
    try:
        with conn.cursor() as cur:
            # db_name/db_user are pre-validated against IDENT_RE above, so
            # this interpolation is safe; MySQL/MariaDB have no way to bind
            # identifiers as query parameters.
            cur.execute(f"CREATE DATABASE `{db_name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci")
            cur.execute(f"CREATE USER `{db_user}`@'localhost' IDENTIFIED BY %s", (db_password,))
            cur.execute(f"GRANT ALL PRIVILEGES ON `{db_name}`.* TO `{db_user}`@'localhost'")
            cur.execute("FLUSH PRIVILEGES")
    finally:
        conn.close()

    with contextlib.closing(db.get_conn()) as conn2:
        conn2.execute(
            "INSERT INTO databases (domain, db_name, db_user, db_password) VALUES (?,?,?,?)",
            (domain, db_name, db_user, db_password),
        )
        conn2.commit()

    db.log(actor, "database_create", db_name, f"user={db_user}")
    return {"db_name": db_name, "db_user": db_user, "db_password": db_password}


def regenerate_password(domain: str, db_name: str, actor: str = "admin") -> str:
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT db_user FROM databases WHERE domain=? AND db_name=?", (domain, db_name)).fetchone()
        if not row:
            raise DatabaseError("Database not found")
        db_user = row["db_user"]

    new_password = secrets.token_urlsafe(18)
    conn = _root_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"ALTER USER `{db_user}`@'localhost' IDENTIFIED BY %s", (new_password,))
            cur.execute("FLUSH PRIVILEGES")
    finally:
        conn.close()

    with contextlib.closing(db.get_conn()) as conn2:
        conn2.execute("UPDATE databases SET db_password=? WHERE domain=? AND db_name=?", (new_password, domain, db_name))
        conn2.commit()
    db.log(actor, "database_regenerate_password", db_name)
    return new_password


def delete_database(domain: str, db_name: str, actor: str = "admin"):
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT db_user FROM databases WHERE domain=? AND db_name=?", (domain, db_name)).fetchone()
        if not row:
            raise DatabaseError("Database not found")
        db_user = row["db_user"]

    conn = _root_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"DROP DATABASE IF EXISTS `{db_name}`")
            cur.execute(f"DROP USER IF EXISTS `{db_user}`@'localhost'")
            cur.execute("FLUSH PRIVILEGES")
    finally:
        conn.close()

    with contextlib.closing(db.get_conn()) as conn2:
        conn2.execute("DELETE FROM databases WHERE domain=? AND db_name=?", (domain, db_name))
        conn2.commit()
    db.log(actor, "database_delete", db_name)
