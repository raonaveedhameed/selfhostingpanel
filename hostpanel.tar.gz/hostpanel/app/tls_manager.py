"""
TLS automation via Let's Encrypt (certbot).

Uses the HTTP-01 webroot challenge against the domain's own httpdocs
directory - no changes to Apache needed before the first request, since
Stage 1's plain-HTTP vhost already serves that directory. Once a
certificate is issued, security.write_apache_vhost() (Stage 1, extended
here) notices the certificate files on disk and regenerates the vhost
as a redirect-to-HTTPS pair automatically - so enabling TLS for a
domain doesn't require hand-editing anything.

Renewal is handled by certbot's own systemd timer (installed by the
`certbot` package) running `certbot renew` on its normal schedule; a
deploy-hook (installed by install_stage4.sh) reloads Apache after a
renewal so the running process picks up the refreshed certificate
without anyone visiting this module again.
"""
import os
import subprocess
import contextlib
from datetime import datetime
from . import config, db, security


class TlsError(Exception):
    pass


def _run(cmd, **kwargs):
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    return result


def certificate_exists(domain: str) -> bool:
    cert_file, key_file, _ = security._cert_paths(domain)
    return os.path.exists(cert_file) and os.path.exists(key_file)


def certificate_expiry(domain: str):
    """Returns the certificate's expiry as a string, or None if it can't
    be determined (missing cert, openssl not available, etc.)."""
    cert_file, _, _ = security._cert_paths(domain)
    if not os.path.exists(cert_file):
        return None
    result = _run(["openssl", "x509", "-enddate", "-noout", "-in", cert_file])
    if result.returncode != 0:
        return None
    # Output looks like "notAfter=Mar 15 12:00:00 2027 GMT"
    line = result.stdout.strip()
    if "=" in line:
        return line.split("=", 1)[1]
    return None


def request_certificate(domain: str, actor: str = "admin") -> dict:
    domain = security.validate_domain(domain)
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT linux_user FROM domains WHERE domain=?", (domain,)).fetchone()
    if not row:
        raise TlsError("Unknown domain - add it as a hosted domain first")
    linux_user = row["linux_user"]

    webroot = os.path.join(config.VHOSTS_ROOT, domain, "httpdocs")
    if not os.path.isdir(webroot):
        raise TlsError(f"Web root not found: {webroot}")

    admin_email = db.get_setting("admin_email") or f"admin@{domain}"

    cmd = [
        "certbot", "certonly", "--webroot",
        "-w", webroot,
        "-d", domain,
        "-d", f"www.{domain}",
        "--non-interactive", "--agree-tos", "--no-eff-email",
        "-m", admin_email,
    ]
    result = _run(cmd)
    if result.returncode != 0:
        db.log(actor, "tls_issue_failed", domain, result.stderr[-500:] if result.stderr else "")
        raise TlsError(
            "Certificate issuance failed. The most common cause is that this domain's DNS "
            "doesn't point at this server yet, or port 80 isn't reachable from the internet. "
            f"certbot said: {result.stderr.strip()[-400:] if result.stderr else 'no output'}"
        )

    # Regenerate the vhost now that the cert files exist on disk, and
    # reload Apache to start serving over HTTPS immediately.
    security.write_apache_vhost(domain, linux_user)
    security.reload_services()

    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "UPDATE domains SET tls_enabled=1, tls_issued_at=? WHERE domain=?",
            (datetime.utcnow().isoformat(timespec="seconds"), domain),
        )
        conn.commit()

    db.log(actor, "tls_issue_success", domain)
    return {"domain": domain, "expiry": certificate_expiry(domain)}
