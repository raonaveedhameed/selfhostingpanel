"""
Mail provisioning for Postfix + Dovecot.

Architecture: Postfix and Dovecot are configured (see installer/
install_stage2.sh) to query hostpanel.db - the same SQLite database the
panel itself uses - directly via their built-in sqlite map/driver
support. There is no separate mail database to keep in sync: enabling a
domain or adding a mailbox here takes effect immediately, because the
mail servers are reading the same rows the panel just wrote.

Mail storage lives under MAIL_VHOST_BASE, entirely separate from any
web-servable vhost directory, owned by a single dedicated `vmail`
system account (uid/gid 5000) - not by the domain's web user. Mail
content is never PHP-executable and doesn't need per-domain Linux
users the way web content does; the separation that matters here is
"mail storage is not reachable from the web root", which a distinct
base directory + owner already guarantees.

Password hashing: SSHA256 (salted SHA-256), computed in pure Python.
Dovecot supports this scheme natively via password_query, and it
avoids ever putting a plaintext password on a subprocess command line
(as shelling out to `doveadm pw -p <password>` would).
"""
import os
import re
import base64
import hashlib
import secrets
import subprocess
import contextlib
from . import config, db, security, dns_manager

LOCAL_PART_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,63}$")


class MailError(Exception):
    pass


def _validate_local_part(local_part: str) -> str:
    local_part = local_part.strip().lower()
    if not LOCAL_PART_RE.match(local_part):
        raise MailError(f"'{local_part}' is not a valid mailbox name")
    return local_part


def hash_password(password: str) -> str:
    if len(password) < 10:
        raise MailError("Mailbox passwords must be at least 10 characters")
    salt = secrets.token_bytes(8)
    digest = hashlib.sha256(password.encode("utf-8") + salt).digest()
    return "{SSHA256}" + base64.b64encode(digest + salt).decode("ascii")


def _run(cmd, **kwargs):
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        raise MailError(f"Command failed: {' '.join(cmd)}\n{result.stderr}")
    return result


def _reload_opendkim():
    try:
        subprocess.run(["systemctl", "reload-or-restart", "opendkim"], capture_output=True, text=True)
    except FileNotFoundError:
        pass


# ---------------------------------------------------------------------
# Domain enable/disable
# ---------------------------------------------------------------------

def mail_enabled(domain: str) -> bool:
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT 1 FROM mail_domains WHERE domain=?", (domain,)).fetchone()
    return row is not None


def enable_mail(domain: str, actor: str = "admin") -> dict:
    domain = security.validate_domain(domain)
    if mail_enabled(domain):
        raise MailError(f"Mail is already enabled for {domain}")

    with contextlib.closing(db.get_conn()) as conn:
        conn.execute("INSERT INTO mail_domains (domain, dkim_selector) VALUES (?,?)", (domain, config.DKIM_SELECTOR))
        conn.commit()

    domain_mail_dir = os.path.join(config.MAIL_VHOST_BASE, domain)
    os.makedirs(domain_mail_dir, exist_ok=True)
    _chown_vmail(domain_mail_dir)
    os.chmod(domain_mail_dir, 0o700)

    dkim_txt = generate_dkim_key(domain)

    dns_manager.ensure_base_records(domain)
    dns_manager.ensure_mail_records(domain, dkim_txt_value=dkim_txt)

    db.log(actor, "mail_enable_domain", domain)
    return {"domain": domain, "dkim_txt": dkim_txt}


def disable_mail(domain: str, actor: str = "admin"):
    if not mail_enabled(domain):
        raise MailError("Mail is not enabled for this domain")
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute("DELETE FROM mail_users WHERE domain=?", (domain,))
        conn.execute("DELETE FROM mail_aliases WHERE domain=?", (domain,))
        conn.execute("DELETE FROM mail_domains WHERE domain=?", (domain,))
        conn.commit()
    remove_dkim_key(domain)
    dns_manager.remove_mail_records(domain)
    # Mailbox content on disk is deliberately left in place (renamed out of
    # the way) rather than deleted, mirroring how domain deletion works.
    domain_mail_dir = os.path.join(config.MAIL_VHOST_BASE, domain)
    if os.path.isdir(domain_mail_dir):
        os.rename(domain_mail_dir, os.path.join(config.MAIL_VHOST_BASE, f".deleted-{domain}-{secrets.token_hex(4)}"))
    db.log(actor, "mail_disable_domain", domain)


def _chown_vmail(path: str):
    try:
        _run(["chown", "-R", f"{config.VMAIL_USER}:{config.VMAIL_USER}", path])
    except MailError:
        pass  # vmail user may not exist yet in a dev/test environment


# ---------------------------------------------------------------------
# DKIM
# ---------------------------------------------------------------------

def generate_dkim_key(domain: str) -> str:
    """Generates an OpenDKIM key pair for domain, wires it into KeyTable/
    SigningTable, and returns the TXT record value for DNS."""
    key_dir = os.path.join(config.DKIM_KEY_DIR, domain)
    os.makedirs(key_dir, exist_ok=True)
    selector = config.DKIM_SELECTOR

    _run(["opendkim-genkey", "-b", "2048", "-d", domain, "-s", selector, "-D", key_dir])
    _run(["chown", "-R", "opendkim:opendkim", key_dir])
    os.chmod(os.path.join(key_dir, f"{selector}.private"), 0o600)

    key_table = f"/etc/opendkim/KeyTable"
    sign_table = f"/etc/opendkim/SigningTable"
    key_entry = f"{selector}._domainkey.{domain} {domain}:{selector}:{key_dir}/{selector}.private\n"
    sign_entry = f"*@{domain} {selector}._domainkey.{domain}\n"
    _append_if_missing(key_table, f"{selector}._domainkey.{domain}", key_entry)
    _append_if_missing(sign_table, f"*@{domain}", sign_entry)

    _reload_opendkim()

    txt_path = os.path.join(key_dir, f"{selector}.txt")
    return _extract_dkim_txt_value(txt_path) if os.path.exists(txt_path) else ""


def _append_if_missing(path: str, marker: str, line: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    existing = ""
    if os.path.exists(path):
        with open(path) as f:
            existing = f.read()
    if marker not in existing:
        with open(path, "a") as f:
            f.write(line)


def _extract_dkim_txt_value(txt_path: str) -> str:
    """opendkim-genkey writes a BIND-format TXT record; concatenate the
    quoted strings into one value suitable for our zone renderer."""
    with open(txt_path) as f:
        content = f.read()
    parts = re.findall(r'"([^"]*)"', content)
    return '"' + "".join(parts) + '"'


def remove_dkim_key(domain: str):
    selector = config.DKIM_SELECTOR
    for path in (
        f"/etc/opendkim/KeyTable",
        f"/etc/opendkim/SigningTable",
    ):
        if not os.path.exists(path):
            continue
        with open(path) as f:
            lines = f.readlines()
        lines = [l for l in lines if domain not in l]
        with open(path, "w") as f:
            f.writelines(lines)
    _reload_opendkim()


# ---------------------------------------------------------------------
# Mailboxes
# ---------------------------------------------------------------------

def list_mailboxes(domain: str):
    with contextlib.closing(db.get_conn()) as conn:
        return conn.execute(
            "SELECT * FROM mail_users WHERE domain=? ORDER BY local_part", (domain,)
        ).fetchall()


def create_mailbox(domain: str, local_part: str, password: str, quota_mb: int = 1024, actor="admin") -> dict:
    domain = security.validate_domain(domain)
    if not mail_enabled(domain):
        raise MailError("Enable mail for this domain first")
    local_part = _validate_local_part(local_part)
    email = f"{local_part}@{domain}"

    with contextlib.closing(db.get_conn()) as conn:
        count = conn.execute("SELECT COUNT(*) c FROM mail_users WHERE domain=?", (domain,)).fetchone()["c"]
        if count >= config.MAX_MAILBOXES_PER_DOMAIN:
            raise MailError(f"Mailbox limit reached for {domain}")
        existing = conn.execute("SELECT 1 FROM mail_users WHERE email=?", (email,)).fetchone()
        if existing:
            raise MailError(f"{email} already exists")
        pw_hash = hash_password(password)
        conn.execute(
            "INSERT INTO mail_users (domain, local_part, email, password_hash, quota_mb) VALUES (?,?,?,?,?)",
            (domain, local_part, email, pw_hash, quota_mb),
        )
        conn.commit()

    maildir = os.path.join(config.MAIL_VHOST_BASE, domain, local_part)
    for sub in ("cur", "new", "tmp"):
        os.makedirs(os.path.join(maildir, "Maildir", sub), exist_ok=True)
    _chown_vmail(os.path.join(config.MAIL_VHOST_BASE, domain))

    db.log(actor, "mail_create_mailbox", email)
    return {"email": email}


def delete_mailbox(domain: str, local_part: str, actor="admin"):
    email = f"{local_part}@{domain}"
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT 1 FROM mail_users WHERE domain=? AND local_part=?", (domain, local_part)).fetchone()
        if not row:
            raise MailError("Mailbox not found")
        conn.execute("DELETE FROM mail_users WHERE domain=? AND local_part=?", (domain, local_part))
        conn.commit()

    maildir = os.path.join(config.MAIL_VHOST_BASE, domain, local_part)
    if os.path.isdir(maildir):
        os.rename(maildir, os.path.join(config.MAIL_VHOST_BASE, domain, f".deleted-{local_part}-{secrets.token_hex(4)}"))

    db.log(actor, "mail_delete_mailbox", email)


def change_mailbox_password(domain: str, local_part: str, new_password: str, actor="admin"):
    pw_hash = hash_password(new_password)
    with contextlib.closing(db.get_conn()) as conn:
        cur = conn.execute(
            "UPDATE mail_users SET password_hash=? WHERE domain=? AND local_part=?",
            (pw_hash, domain, local_part),
        )
        conn.commit()
        if cur.rowcount == 0:
            raise MailError("Mailbox not found")
    db.log(actor, "mail_change_password", f"{local_part}@{domain}")


# ---------------------------------------------------------------------
# Aliases
# ---------------------------------------------------------------------

def list_aliases(domain: str):
    with contextlib.closing(db.get_conn()) as conn:
        return conn.execute("SELECT * FROM mail_aliases WHERE domain=? ORDER BY source", (domain,)).fetchall()


def create_alias(domain: str, source_local: str, destination: str, actor="admin") -> dict:
    domain = security.validate_domain(domain)
    if not mail_enabled(domain):
        raise MailError("Enable mail for this domain first")
    source_local = _validate_local_part(source_local)
    destination = destination.strip().lower()
    if "@" not in destination:
        raise MailError("Destination must be a full email address")
    source = f"{source_local}@{domain}"

    with contextlib.closing(db.get_conn()) as conn:
        existing = conn.execute(
            "SELECT 1 FROM mail_aliases WHERE domain=? AND source=? AND destination=?",
            (domain, source, destination),
        ).fetchone()
        if existing:
            raise MailError("This alias already exists")
        conn.execute(
            "INSERT INTO mail_aliases (domain, source, destination) VALUES (?,?,?)",
            (domain, source, destination),
        )
        conn.commit()
    db.log(actor, "mail_create_alias", f"{source} -> {destination}")
    return {"source": source, "destination": destination}


def delete_alias(alias_id: int, domain: str, actor="admin"):
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT * FROM mail_aliases WHERE id=? AND domain=?", (alias_id, domain)).fetchone()
        if not row:
            raise MailError("Alias not found")
        conn.execute("DELETE FROM mail_aliases WHERE id=?", (alias_id,))
        conn.commit()
    db.log(actor, "mail_delete_alias", f"id={alias_id}")
