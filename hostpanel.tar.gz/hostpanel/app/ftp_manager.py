"""
FTP account provisioning for ProFTPD.

Every domain gets one "primary" FTP account automatically when the
domain is created - same username as the domain's Linux system user,
same uid/gid, home directory the whole vhost. No separate identity to
manage: it's a login credential layered on top of the isolation Stage 1
already built, not a new isolation model.

Admins can also create scoped "additional" FTP accounts (e.g. handing a
developer access to just httpdocs/ without touching the rest of the
vhost) - these share the domain's uid/gid so on-disk ownership is
unaffected, but ProFTPD chroots them to a narrower home directory.

ProFTPD reads this table directly via mod_sql (see installer/
install_stage3.sh) - the same "one source of truth" pattern used for
mail in Stage 2. Password hashing uses SHA-512-crypt, which ProFTPD's
built-in "Crypt" SQLAuthType verifies natively with no extra plugin.
"""
import os
import re
import secrets
import contextlib
from . import config, db, security

LABEL_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._-]{0,31}$")


class FtpError(Exception):
    pass


def hash_password(password: str) -> str:
    if len(password) < 10:
        raise FtpError("FTP passwords must be at least 10 characters")
    try:
        import crypt
        salt = crypt.mksalt(crypt.METHOD_SHA512)
        return crypt.crypt(password, salt)
    except ImportError:
        # The stdlib `crypt` module was removed in Python 3.13. Fall back
        # to OpenSSL, feeding the password on stdin (never argv/env) so it
        # never appears in a process listing.
        import subprocess
        salt = secrets.token_hex(8)
        result = subprocess.run(
            ["openssl", "passwd", "-6", "-salt", salt, "-stdin"],
            input=password, capture_output=True, text=True,
        )
        if result.returncode != 0:
            raise FtpError("Could not hash FTP password (openssl failed)")
        return result.stdout.strip()


def _vhost_root(domain: str) -> str:
    domain = security.validate_domain(domain)
    return os.path.realpath(os.path.join(config.VHOSTS_ROOT, domain))


def _safe_subpath(domain: str, relative: str) -> str:
    root = _vhost_root(domain)
    relative = (relative or "").strip("/")
    candidate = os.path.realpath(os.path.join(root, relative))
    if candidate != root and not candidate.startswith(root + os.sep):
        raise FtpError("That path is outside the domain's vhost directory")
    return candidate


# ---------------------------------------------------------------------
# Primary account (one per domain, created automatically)
# ---------------------------------------------------------------------

def ensure_primary_account(domain: str, uid: int, linux_user: str):
    home = _vhost_root(domain)
    with contextlib.closing(db.get_conn()) as conn:
        existing = conn.execute("SELECT 1 FROM ftp_accounts WHERE domain=? AND is_primary=1", (domain,)).fetchone()
        if existing:
            return
        conn.execute(
            "INSERT INTO ftp_accounts (domain, username, password_hash, uid, gid, home_dir, is_primary) "
            "VALUES (?,?,?,?,?,?,1)",
            (domain, linux_user, None, uid, uid, home),
        )
        conn.commit()


def disable_all_for_domain(domain: str, actor: str = "admin"):
    """Called when a domain is deleted - accounts are disabled, not
    dropped, mirroring how domain/mailbox deletion works elsewhere."""
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute("UPDATE ftp_accounts SET status='disabled' WHERE domain=?", (domain,))
        conn.commit()
    db.log(actor, "ftp_disable_domain_accounts", domain)


# ---------------------------------------------------------------------
# Password management
# ---------------------------------------------------------------------

def set_password(domain: str, username: str, new_password: str, actor: str = "admin"):
    pw_hash = hash_password(new_password)
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT 1 FROM ftp_accounts WHERE domain=? AND username=?", (domain, username)).fetchone()
        if not row:
            raise FtpError("FTP account not found")
        conn.execute("UPDATE ftp_accounts SET password_hash=? WHERE domain=? AND username=?", (pw_hash, domain, username))
        conn.commit()
    db.log(actor, "ftp_set_password", username)


# ---------------------------------------------------------------------
# Additional scoped accounts
# ---------------------------------------------------------------------

def list_accounts(domain: str):
    with contextlib.closing(db.get_conn()) as conn:
        return conn.execute(
            "SELECT * FROM ftp_accounts WHERE domain=? ORDER BY is_primary DESC, username", (domain,)
        ).fetchall()


def create_subaccount(domain: str, label: str, subpath: str, password: str, actor: str = "admin") -> dict:
    domain = security.validate_domain(domain)
    label = label.strip().lower()
    if not LABEL_RE.match(label):
        raise FtpError(f"'{label}' is not a valid account label")
    username = f"{label}@{domain}"

    with contextlib.closing(db.get_conn()) as conn:
        count = conn.execute(
            "SELECT COUNT(*) c FROM ftp_accounts WHERE domain=? AND is_primary=0", (domain,)
        ).fetchone()["c"]
        if count >= config.MAX_FTP_SUBACCOUNTS_PER_DOMAIN:
            raise FtpError(f"FTP account limit reached for {domain}")
        if conn.execute("SELECT 1 FROM ftp_accounts WHERE username=?", (username,)).fetchone():
            raise FtpError(f"{username} already exists")

        home = _safe_subpath(domain, subpath)
        os.makedirs(home, exist_ok=True)

        domain_row = conn.execute("SELECT uid FROM domains WHERE domain=?", (domain,)).fetchone()
        if not domain_row:
            raise FtpError("Unknown domain")
        uid = domain_row["uid"]

        pw_hash = hash_password(password)
        conn.execute(
            "INSERT INTO ftp_accounts (domain, username, password_hash, uid, gid, home_dir, is_primary) "
            "VALUES (?,?,?,?,?,?,0)",
            (domain, username, pw_hash, uid, uid, home),
        )
        conn.commit()

    security.apply_ownership(domain, security._get_linux_user(domain))
    db.log(actor, "ftp_create_subaccount", username, f"home={home}")
    return {"username": username, "home_dir": home}


def delete_subaccount(domain: str, username: str, actor: str = "admin"):
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute(
            "SELECT is_primary FROM ftp_accounts WHERE domain=? AND username=?", (domain, username)
        ).fetchone()
        if not row:
            raise FtpError("FTP account not found")
        if row["is_primary"]:
            raise FtpError("The primary FTP account can't be deleted - remove the domain instead")
        conn.execute("DELETE FROM ftp_accounts WHERE domain=? AND username=?", (domain, username))
        conn.commit()
    db.log(actor, "ftp_delete_subaccount", username)
