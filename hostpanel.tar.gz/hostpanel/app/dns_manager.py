"""
DNS management via BIND (named).

Design choice: DNS records live in SQLite, not in hand-edited zone
files. Every change rewrites the domain's zone file in full from the
database and reloads that one zone via `rndc reload <zone>`. This
avoids the class of bugs you get from parsing/patching zone file text
in place, at the cost of a rewrite per change - which is cheap, zone
files are tiny.

Records are tagged 'auto' (created/refreshed by the panel - NS/A glue,
and later MX/SPF/DKIM when mail is enabled) or 'custom' (added by the
admin). Regeneration only touches 'auto' rows for a given (domain,
name, type) key, so a custom TXT record next to an auto MX record is
left alone.
"""
import os
import time
import subprocess
import contextlib
from . import config, db, security


class DnsError(Exception):
    pass


def server_ip() -> str:
    ip = db.get_setting("server_ip")
    if not ip:
        raise DnsError("Server IP is not configured yet - set it on the Settings page first.")
    return ip


def _upsert_auto(domain: str, rtype: str, name: str, value: str, priority: int = 0, ttl: int = None,
                  allow_multiple: bool = False):
    """Insert or update an auto-managed record.

    Most auto records are singletons per (domain, type, name) - e.g. there
    is exactly one apex A record, so a repeat call (say, after the server
    IP changes) should update that row in place rather than duplicate it.

    NS records are the exception: a domain legitimately has two different
    NS values (ns1, ns2) under the same name '@'. For those, pass
    allow_multiple=True so the match includes `value`, keeping ns1 and
    ns2 as distinct rows instead of collapsing into one.
    """
    ttl = ttl or config.DEFAULT_TTL
    with contextlib.closing(db.get_conn()) as conn:
        if allow_multiple:
            existing = conn.execute(
                "SELECT id FROM dns_records WHERE domain=? AND type=? AND name=? AND source='auto' AND priority=? AND value=?",
                (domain, rtype, name, priority, value),
            ).fetchone()
        else:
            existing = conn.execute(
                "SELECT id FROM dns_records WHERE domain=? AND type=? AND name=? AND source='auto' AND priority=?",
                (domain, rtype, name, priority),
            ).fetchone()
        if existing:
            conn.execute("UPDATE dns_records SET value=?, ttl=? WHERE id=?", (value, ttl, existing["id"]))
        else:
            conn.execute(
                "INSERT INTO dns_records (domain, type, name, value, priority, ttl, source) "
                "VALUES (?,?,?,?,?,?, 'auto')",
                (domain, rtype, name, value, priority, ttl),
            )
        conn.commit()


def ensure_base_records(domain: str):
    """Called when a domain is first created: NS + glue A records + apex A + www CNAME."""
    ip = server_ip()
    _upsert_auto(domain, "NS", "@", f"ns1.{domain}.", allow_multiple=True)
    _upsert_auto(domain, "NS", "@", f"ns2.{domain}.", allow_multiple=True)
    _upsert_auto(domain, "A", "ns1", ip)
    _upsert_auto(domain, "A", "ns2", ip)
    _upsert_auto(domain, "A", "@", ip)
    _upsert_auto(domain, "CNAME", "www", f"{domain}.")
    create_zone_file(domain)


def ensure_mail_records(domain: str, dkim_txt_value: str = None):
    """Called when mail is enabled for a domain: MX + SPF, and DKIM once the key exists."""
    _upsert_auto(domain, "MX", "@", f"{domain}.", priority=10)
    _upsert_auto(domain, "TXT", "@", f"\"v=spf1 mx a:{domain} -all\"")
    _upsert_auto(domain, "TXT", "_dmarc", f"\"v=DMARC1; p=quarantine; rua=mailto:postmaster@{domain}\"")
    if dkim_txt_value:
        _upsert_auto(domain, "TXT", f"{config.DKIM_SELECTOR}._domainkey", dkim_txt_value)
    create_zone_file(domain)


def remove_mail_records(domain: str):
    """Called when mail is disabled for a domain: drops the auto MX/SPF/DMARC/DKIM
    records this panel added, leaving any custom records the admin added untouched."""
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "DELETE FROM dns_records WHERE domain=? AND source='auto' AND "
            "(type='MX' OR (type='TXT' AND (name='@' OR name LIKE '%_domainkey' OR name='_dmarc')))",
            (domain,),
        )
        conn.commit()
    create_zone_file(domain)


def add_record(domain: str, rtype: str, name: str, value: str, priority: int = 0, ttl: int = None, actor="admin"):
    domain = security.validate_domain(domain)
    rtype = rtype.upper().strip()
    if rtype not in ("A", "AAAA", "CNAME", "MX", "TXT", "NS", "SRV"):
        raise DnsError(f"Unsupported record type: {rtype}")
    ttl = ttl or config.DEFAULT_TTL
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "INSERT INTO dns_records (domain, type, name, value, priority, ttl, source) VALUES (?,?,?,?,?,?, 'custom')",
            (domain, rtype, name.strip() or "@", value.strip(), priority, ttl),
        )
        conn.commit()
    create_zone_file(domain)
    db.log(actor, "dns_add_record", domain, f"{rtype} {name} {value}")


def delete_record(domain: str, record_id: int, actor="admin"):
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT * FROM dns_records WHERE id=? AND domain=?", (record_id, domain)).fetchone()
        if not row:
            raise DnsError("Record not found")
        if row["source"] == "auto":
            raise DnsError("This record is managed automatically and can't be deleted directly")
        conn.execute("DELETE FROM dns_records WHERE id=?", (record_id,))
        conn.commit()
    create_zone_file(domain)
    db.log(actor, "dns_delete_record", domain, f"id={record_id}")


def list_records(domain: str):
    with contextlib.closing(db.get_conn()) as conn:
        rows = conn.execute(
            "SELECT * FROM dns_records WHERE domain=? ORDER BY type, name", (domain,)
        ).fetchall()
    return rows


# ---------------------------------------------------------------------
# Zone file rendering + BIND integration
# ---------------------------------------------------------------------

def _serial() -> int:
    return int(time.time())


def render_zone(domain: str) -> str:
    rows = list_records(domain)
    lines = [
        f"$TTL {config.DEFAULT_TTL}",
        f"@ IN SOA ns1.{domain}. hostmaster.{domain}. (",
        f"    {_serial()} ; serial",
        f"    {config.DEFAULT_SOA_REFRESH} ; refresh",
        f"    {config.DEFAULT_SOA_RETRY} ; retry",
        f"    {config.DEFAULT_SOA_EXPIRE} ; expire",
        f"    {config.DEFAULT_SOA_MINTTL} ) ; minimum",
        "",
    ]
    for r in rows:
        name = r["name"] if r["name"] != "@" else "@"
        if r["type"] == "MX":
            lines.append(f"{name} {r['ttl']} IN MX {r['priority']} {r['value']}")
        else:
            lines.append(f"{name} {r['ttl']} IN {r['type']} {r['value']}")
    return "\n".join(lines) + "\n"


def create_zone_file(domain: str):
    os.makedirs(config.BIND_ZONE_DIR, exist_ok=True)
    zone_path = os.path.join(config.BIND_ZONE_DIR, f"{domain}.zone")
    with open(zone_path, "w") as f:
        f.write(render_zone(domain))
    os.chmod(zone_path, 0o644)
    _ensure_zone_declared(domain, zone_path)
    _reload_zone(domain)


ZONE_DECL_TEMPLATE = 'zone "{domain}" IN {{ type master; file "{path}"; allow-update {{ none; }}; }};\n'


def _ensure_zone_declared(domain: str, zone_path: str):
    os.makedirs(os.path.dirname(config.BIND_INCLUDE_FILE), exist_ok=True)
    existing = ""
    if os.path.exists(config.BIND_INCLUDE_FILE):
        with open(config.BIND_INCLUDE_FILE) as f:
            existing = f.read()
    marker = f'zone "{domain}"'
    if marker not in existing:
        with open(config.BIND_INCLUDE_FILE, "a") as f:
            f.write(ZONE_DECL_TEMPLATE.format(domain=domain, path=zone_path))
        _reload_named_full()


def remove_zone(domain: str, actor="admin"):
    zone_path = os.path.join(config.BIND_ZONE_DIR, f"{domain}.zone")
    if os.path.exists(zone_path):
        os.remove(zone_path)
    if os.path.exists(config.BIND_INCLUDE_FILE):
        with open(config.BIND_INCLUDE_FILE) as f:
            lines = f.readlines()
        lines = [l for l in lines if f'zone "{domain}"' not in l]
        with open(config.BIND_INCLUDE_FILE, "w") as f:
            f.writelines(lines)
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute("DELETE FROM dns_records WHERE domain=?", (domain,))
        conn.commit()
    _reload_named_full()
    db.log(actor, "dns_remove_zone", domain)


def _reload_zone(domain: str):
    try:
        subprocess.run(["rndc", "reload", domain], capture_output=True, text=True)
    except FileNotFoundError:
        pass  # BIND not installed/reachable - caller already wrote the zone file to disk


def _reload_named_full():
    try:
        subprocess.run(["named-checkconf"], capture_output=True, text=True)
        subprocess.run(["systemctl", "reload-or-restart", "named"], capture_output=True, text=True)
    except FileNotFoundError:
        pass
