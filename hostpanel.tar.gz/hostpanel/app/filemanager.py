"""
File manager operations, scoped strictly to a single domain's vhost
directory. Every function re-derives and re-validates the real,
resolved path before touching disk - this is the only thing standing
between a panel bug and a customer reading another customer's files,
so it is deliberately paranoid and repeated rather than trusted once
at the top of a request.
"""
import os
import shutil
import pwd
import grp
from . import config, security


class FileAccessError(Exception):
    pass


def _vhost_root(domain: str) -> str:
    domain = security.validate_domain(domain)
    root = os.path.realpath(os.path.join(config.VHOSTS_ROOT, domain))
    if not os.path.isdir(root):
        raise FileAccessError("Unknown domain")
    return root


def safe_path(domain: str, relative: str) -> str:
    """Resolve `relative` against the domain's vhost root and guarantee
    the result cannot escape it (blocks '..', absolute paths, symlink
    tricks)."""
    root = _vhost_root(domain)
    relative = (relative or "").lstrip("/")
    candidate = os.path.realpath(os.path.join(root, relative))
    if candidate != root and not candidate.startswith(root + os.sep):
        raise FileAccessError("Path escapes the vhost directory")
    return candidate


def list_dir(domain: str, relative: str = ""):
    path = safe_path(domain, relative)
    if not os.path.isdir(path):
        raise FileAccessError("Not a directory")
    entries = []
    for name in sorted(os.listdir(path)):
        full = os.path.join(path, name)
        try:
            st = os.lstat(full)
        except FileNotFoundError:
            continue
        entries.append({
            "name": name,
            "is_dir": os.path.isdir(full) and not os.path.islink(full),
            "size": st.st_size,
            "mode": oct(st.st_mode & 0o777),
            "mtime": st.st_mtime,
        })
    return entries


def read_file(domain: str, relative: str) -> str:
    path = safe_path(domain, relative)
    if os.path.getsize(path) > config.MAX_EDIT_FILE_MB * 1024 * 1024:
        raise FileAccessError("File too large to edit in browser")
    with open(path, "r", errors="replace") as f:
        return f.read()


def write_file(domain: str, relative: str, content: str):
    path = safe_path(domain, relative)
    with open(path, "w") as f:
        f.write(content)
    _reown(domain, path)


def delete_path(domain: str, relative: str):
    path = safe_path(domain, relative)
    if path == _vhost_root(domain):
        raise FileAccessError("Cannot delete the vhost root")
    if os.path.isdir(path) and not os.path.islink(path):
        shutil.rmtree(path)
    else:
        os.remove(path)


def make_dir(domain: str, relative: str):
    path = safe_path(domain, relative)
    os.makedirs(path, exist_ok=False)
    _reown(domain, path)


def save_upload(domain: str, relative_dir: str, filename: str, file_obj):
    filename = os.path.basename(filename)
    if not filename or filename in (".", ".."):
        raise FileAccessError("Invalid filename")
    dest_dir = safe_path(domain, relative_dir)
    dest = os.path.join(dest_dir, filename)
    dest = safe_path(domain, os.path.relpath(dest, _vhost_root(domain)))

    size = 0
    limit = config.MAX_UPLOAD_MB * 1024 * 1024
    with open(dest, "wb") as out:
        while True:
            chunk = file_obj.read(1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            if size > limit:
                out.close()
                os.remove(dest)
                raise FileAccessError(f"Upload exceeds {config.MAX_UPLOAD_MB}MB limit")
            out.write(chunk)

    # Never let an uploaded file be executable, and always hand
    # ownership back to the domain's own user immediately.
    os.chmod(dest, 0o640)
    _reown(domain, dest)


def _reown(domain: str, path: str):
    """Immediately restore correct ownership after any panel-driven
    write, instead of waiting for the periodic hardening sweep."""
    linux_user = security._get_linux_user(domain)
    try:
        uid = pwd.getpwnam(linux_user).pw_uid
        gid = grp.getgrnam(linux_user).gr_gid
        os.chown(path, uid, gid)
    except (KeyError, PermissionError):
        pass
