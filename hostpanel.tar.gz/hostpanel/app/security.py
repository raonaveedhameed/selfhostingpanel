"""
Domain provisioning and filesystem hardening.

Design principle: the customer never has to *configure* isolation -
every domain automatically gets:

  1. Its own dedicated, unprivileged Linux system user (nologin shell).
  2. Its own PHP-FPM pool running AS that user (not as 'apache'), with
     open_basedir locked to the vhost and dangerous functions disabled.
  3. An Apache vhost that forces PHP execution off inside upload/cache
     directories, blocks dotfiles, and sends hardening headers.
  4. A filesystem layout where the only writable path is the vhost
     itself, owned by the domain's own user - so a compromised site
     cannot read or write any other customer's files, even though
     Apache/PHP-FPM master processes still run as root/apache.
  5. A recurring permission sweep (see harden_all()) that repairs any
     drift - world-writable files, wrong ownership, unexpected SUID
     bits, symlinks that escape the vhost - without an admin having to
     notice anything is wrong.

All subprocess calls use argument lists (never shell=True) and every
domain name is validated before being used to build a path or a
system username.
"""
import os
import re
import pwd
import stat
import subprocess
import secrets
import contextlib
from . import config, db

DOMAIN_RE = re.compile(r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))+$")


class ProvisionError(Exception):
    pass


def validate_domain(domain: str) -> str:
    domain = domain.strip().lower()
    if not DOMAIN_RE.match(domain):
        raise ProvisionError(f"'{domain}' is not a valid domain name")
    return domain


def _linux_username_for(domain: str) -> str:
    # Linux usernames are capped at 32 chars and can't contain dots.
    # Prefix with 'w' + a short hash suffix to keep it unique & valid
    # even for long domains, while staying human-recognisable.
    base = re.sub(r"[^a-z0-9]", "", domain.split(".")[0])[:16] or "site"
    suffix = domain.encode().hex()[:6]
    return f"w{base}{suffix}"[:32]


def _run(cmd: list, **kwargs):
    result = subprocess.run(cmd, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        raise ProvisionError(f"Command failed: {' '.join(cmd)}\n{result.stderr}")
    return result


def _next_free_uid() -> int:
    used = {p.pw_uid for p in pwd.getpwall()}
    uid = config.DOMAIN_UID_MIN
    while uid in used:
        uid += 1
    return uid


# --------------------------------------------------------------------
# Provisioning
# --------------------------------------------------------------------

def create_domain(domain: str, actor: str = "admin") -> dict:
    domain = validate_domain(domain)
    linux_user = _linux_username_for(domain)
    home = os.path.join(config.VHOSTS_ROOT, domain)

    if os.path.exists(home):
        raise ProvisionError(f"Directory already exists for {domain}")

    uid = _next_free_uid()

    # 1. Dedicated system user, no login shell, no password.
    _run([
        "useradd",
        "--uid", str(uid),
        "--home-dir", home,
        "--create-home",
        "--shell", "/sbin/nologin",
        "--comment", f"hostpanel:{domain}",
        linux_user,
    ])
    _run(["passwd", "-l", linux_user])  # lock password login entirely

    # 2. Vhost directory layout.
    subdirs = ["httpdocs", "logs", "private", "tmp", "conf"]
    for sub in subdirs:
        path = os.path.join(home, sub)
        os.makedirs(path, exist_ok=True)

    with open(os.path.join(home, "httpdocs", "index.html"), "w") as f:
        f.write(f"<h1>{domain}</h1><p>Site provisioned. Upload your files via the file manager.</p>")

    apply_ownership(domain, linux_user)

    # 3. PHP-FPM pool running as the domain's own user.
    write_php_fpm_pool(domain, linux_user)

    # 4. Apache vhost.
    write_apache_vhost(domain, linux_user)

    reload_services()

    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "INSERT INTO domains (domain, linux_user, uid) VALUES (?,?,?)",
            (domain, linux_user, uid),
        )
        conn.commit()
    db.log(actor, "create_domain", domain, f"user={linux_user} uid={uid}")

    # DNS: give the domain a working zone (NS/A/www) immediately. Imported
    # locally to avoid a circular import (dns_manager imports this module).
    try:
        from . import dns_manager
        dns_manager.ensure_base_records(domain)
    except Exception as e:
        db.log(actor, "dns_autoprovision_failed", domain, str(e))

    # FTP: every domain gets a primary FTP account (same identity as the
    # Linux user above) automatically - the admin just needs to set a
    # password for it on the domain's FTP page.
    try:
        from . import ftp_manager
        ftp_manager.ensure_primary_account(domain, uid, linux_user)
    except Exception as e:
        db.log(actor, "ftp_autoprovision_failed", domain, str(e))

    return {"domain": domain, "linux_user": linux_user, "uid": uid, "home": home}


def delete_domain(domain: str, actor: str = "admin"):
    domain = validate_domain(domain)
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT linux_user FROM domains WHERE domain=?", (domain,)).fetchone()
        if not row:
            raise ProvisionError("Unknown domain")
        linux_user = row["linux_user"]
        conn.execute("DELETE FROM domains WHERE domain=?", (domain,))
        conn.commit()

    pool_file = os.path.join(config.PHP_FPM_POOL_DIR, f"{domain}.conf")
    vhost_file = os.path.join(config.APACHE_VHOST_DIR, f"{domain}.conf")
    for f in (pool_file, vhost_file):
        if os.path.exists(f):
            os.remove(f)

    # Remove the system user but deliberately KEEP the home directory
    # (renamed) for a grace period instead of destroying data instantly.
    home = os.path.join(config.VHOSTS_ROOT, domain)
    trashed = os.path.join(config.VHOSTS_ROOT, f".deleted-{domain}-{secrets.token_hex(4)}")
    if os.path.exists(home):
        os.rename(home, trashed)
    _run(["userdel", linux_user])

    reload_services()
    db.log(actor, "delete_domain", domain, f"data moved to {trashed}")

    try:
        from . import dns_manager
        dns_manager.remove_zone(domain, actor=actor)
    except Exception as e:
        db.log(actor, "dns_removal_failed", domain, str(e))

    try:
        from . import ftp_manager
        ftp_manager.disable_all_for_domain(domain, actor=actor)
    except Exception as e:
        db.log(actor, "ftp_removal_failed", domain, str(e))


def suspend_domain(domain: str, actor: str = "admin"):
    domain = validate_domain(domain)
    linux_user = _get_linux_user(domain)
    _run(["usermod", "-L", linux_user])
    # Point the vhost at a "suspended" static page instead of tearing down config.
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute("UPDATE domains SET status='suspended' WHERE domain=?", (domain,))
        conn.commit()
    db.log(actor, "suspend_domain", domain)


def _get_linux_user(domain: str) -> str:
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT linux_user FROM domains WHERE domain=?", (domain,)).fetchone()
    if not row:
        raise ProvisionError("Unknown domain")
    return row["linux_user"]


# --------------------------------------------------------------------
# PHP-FPM pool (per-domain isolation)
# --------------------------------------------------------------------

PHP_FPM_POOL_TEMPLATE = """\
; Auto-generated by hostpanel - do not edit by hand, changes are overwritten.
[{domain}]
user = {user}
group = {user}
listen = {sock}
listen.owner = {apache_user}
listen.group = {apache_group}
listen.mode = 0660

pm = ondemand
pm.max_children = 8
pm.process_idle_timeout = 30s
pm.max_requests = 500

; --- Hardening -------------------------------------------------------
; Confine this pool to its own vhost only. Even a full RCE in this
; site's PHP code cannot read/write any other customer's files.
php_admin_value[open_basedir] = {home}:/tmp:/usr/share/php:/dev/urandom
php_admin_value[disable_functions] = {disabled_functions}
php_admin_flag[allow_url_fopen] = off
php_admin_flag[allow_url_include] = off
php_admin_flag[expose_php] = off
php_admin_flag[display_errors] = off
php_admin_flag[log_errors] = on
php_admin_value[error_log] = {home}/logs/php_errors.log
php_admin_value[session.save_path] = {home}/tmp
php_admin_value[upload_tmp_dir] = {home}/tmp
php_admin_value[upload_max_filesize] = 128M
php_admin_value[post_max_size] = 128M
php_admin_value[max_execution_time] = 60
security.limit_extensions = .php
"""


def write_php_fpm_pool(domain: str, user: str):
    home = os.path.join(config.VHOSTS_ROOT, domain)
    sock = os.path.join(config.PHP_FPM_SOCK_DIR, f"{domain}.sock")
    content = PHP_FPM_POOL_TEMPLATE.format(
        domain=domain,
        user=user,
        sock=sock,
        apache_user=config.APACHE_USER,
        apache_group=config.APACHE_GROUP,
        home=home,
        disabled_functions=config.PHP_DISABLED_FUNCTIONS,
    )
    os.makedirs(config.PHP_FPM_POOL_DIR, exist_ok=True)
    pool_path = os.path.join(config.PHP_FPM_POOL_DIR, f"{domain}.conf")
    with open(pool_path, "w") as f:
        f.write(content)
    os.chmod(pool_path, 0o644)


# --------------------------------------------------------------------
# Apache vhost
# --------------------------------------------------------------------

# Shared between the plain-HTTP and TLS vhosts so the two never drift
# out of sync with each other.
COMMON_VHOST_BLOCK = """\
    ServerName {domain}
    ServerAlias www.{domain}
    DocumentRoot {home}/httpdocs

    ErrorLog {home}/logs/error.log
    CustomLog {home}/logs/access.log combined

    <FilesMatch "\\.php$">
        SetHandler "proxy:unix:{sock}|fcgi://localhost"
    </FilesMatch>

    <Directory "{home}/httpdocs">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # Block access to dotfiles (.env, .git, .htpasswd, etc.)
    <FilesMatch "^\\.">
        Require all denied
    </FilesMatch>

    # Force PHP execution off in upload/cache directories - the classic
    # web-shell persistence trick even when the pool user is contained.
{no_php_blocks}

    # Security headers
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
    Header always set Referrer-Policy "strict-origin-when-cross-origin"
    Header always set X-XSS-Protection "1; mode=block"
"""

HTTP_VHOST_PLAIN_TEMPLATE = """\
# Auto-generated by hostpanel - do not edit by hand, changes are overwritten.
<VirtualHost *:80>
{common}
</VirtualHost>
"""

# Used once a domain has a TLS certificate: port 80 only serves ACME
# renewal challenges and otherwise redirects to https, so plaintext
# HTTP never reaches PHP once encryption is available.
HTTP_VHOST_REDIRECT_TEMPLATE = """\
# Auto-generated by hostpanel - do not edit by hand, changes are overwritten.
<VirtualHost *:80>
    ServerName {domain}
    ServerAlias www.{domain}
    DocumentRoot {home}/httpdocs

    RewriteEngine On
    RewriteCond %{{REQUEST_URI}} !^/\\.well-known/acme-challenge/
    RewriteRule ^ https://%{{HTTP_HOST}}%{{REQUEST_URI}} [L,R=301]
</VirtualHost>

<VirtualHost *:443>
    SSLEngine on
    SSLCertificateFile {cert_file}
    SSLCertificateKeyFile {key_file}
    SSLCertificateChainFile {chain_file}
{common}
    Header always set Strict-Transport-Security "max-age=15552000; includeSubDomains"
</VirtualHost>
"""

NO_PHP_BLOCK_TEMPLATE = """\
    <Directory "{path}">
        php_admin_flag engine off
        <FilesMatch "\\.(php|phtml|php\\d)$">
            Require all denied
        </FilesMatch>
    </Directory>
"""


def _cert_paths(domain: str):
    live_dir = f"/etc/letsencrypt/live/{domain}"
    return (
        os.path.join(live_dir, "fullchain.pem"),
        os.path.join(live_dir, "privkey.pem"),
        os.path.join(live_dir, "chain.pem"),
    )


def write_apache_vhost(domain: str, user: str):
    home = os.path.join(config.VHOSTS_ROOT, domain)
    sock = os.path.join(config.PHP_FPM_SOCK_DIR, f"{domain}.sock")
    no_php_blocks = "\n".join(
        NO_PHP_BLOCK_TEMPLATE.format(path=os.path.join(home, sub))
        for sub in config.NO_PHP_EXEC_SUBDIRS
    )
    common = COMMON_VHOST_BLOCK.format(
        domain=domain, home=home, sock=sock, no_php_blocks=no_php_blocks,
    )

    cert_file, key_file, chain_file = _cert_paths(domain)
    has_cert = os.path.exists(cert_file) and os.path.exists(key_file)

    if has_cert:
        content = HTTP_VHOST_REDIRECT_TEMPLATE.format(
            domain=domain, home=home, cert_file=cert_file, key_file=key_file,
            chain_file=chain_file, common=common,
        )
    else:
        content = HTTP_VHOST_PLAIN_TEMPLATE.format(common=common)

    os.makedirs(config.APACHE_VHOST_DIR, exist_ok=True)
    vhost_path = os.path.join(config.APACHE_VHOST_DIR, f"{domain}.conf")
    with open(vhost_path, "w") as f:
        f.write(content)
    os.chmod(vhost_path, 0o644)


def reload_services():
    for svc in ("php-fpm", "httpd"):
        subprocess.run(["systemctl", "reload-or-restart", svc], capture_output=True, text=True)


# --------------------------------------------------------------------
# Ownership / permission hardening
# --------------------------------------------------------------------

def apply_ownership(domain: str, user: str):
    """Set correct owner:group and a safe permission baseline across a vhost."""
    home = os.path.join(config.VHOSTS_ROOT, domain)
    _run(["chown", "-R", f"{user}:{user}", home])
    os.chmod(home, 0o750)
    for root, dirs, files in os.walk(home):
        for d in dirs:
            _safe_chmod(os.path.join(root, d), 0o750)
        for fname in files:
            _safe_chmod(os.path.join(root, fname), 0o640)
    # logs directory must be readable by the panel but the vhost's own
    # httpdocs needs to be servable by apache via the fpm proxy, so give
    # the apache group execute-only traversal, never write.
    _run(["setfacl", "-R", "-m", f"g:{config.APACHE_GROUP}:rx", home], check=False) \
        if _has_setfacl() else None


def _has_setfacl():
    return subprocess.run(["which", "setfacl"], capture_output=True).returncode == 0


def _safe_chmod(path: str, mode: int):
    try:
        st = os.lstat(path)
        if stat.S_ISLNK(st.st_mode):
            return  # never follow/alter symlinks here
        os.chmod(path, mode)
    except FileNotFoundError:
        pass


def harden_all(actor: str = "cron"):
    """
    Idempotent sweep run every few minutes by systemd timer. Repairs
    drift so the customer never has to think about permissions:
      - resets any world-writable file/dir
      - strips unexpected SUID/SGID bits
      - fixes ownership back to the vhost's own user
      - removes symlinks that point outside the vhost (containment escape)
      - enforces max permission ceiling (no 777, no o+w)
    """
    if not os.path.isdir(config.VHOSTS_ROOT):
        return
    with contextlib.closing(db.get_conn()) as conn:
        domains = conn.execute("SELECT domain, linux_user FROM domains WHERE status='active'").fetchall()

    findings = []
    for row in domains:
        domain, user = row["domain"], row["linux_user"]
        home = os.path.realpath(os.path.join(config.VHOSTS_ROOT, domain))
        if not os.path.isdir(home):
            continue
        try:
            expected_uid = pwd.getpwnam(user).pw_uid
        except KeyError:
            continue

        for root, dirs, files in os.walk(home, topdown=True):
            for name in list(dirs) + list(files):
                full = os.path.join(root, name)
                try:
                    st = os.lstat(full)
                except FileNotFoundError:
                    continue

                # Symlink escape check: resolved target must stay inside the vhost.
                if stat.S_ISLNK(st.st_mode):
                    target = os.path.realpath(full)
                    if not target.startswith(home + os.sep):
                        os.remove(full)
                        findings.append(f"{domain}: removed escaping symlink {full}")
                    continue

                # Strip SUID/SGID - never legitimate inside a vhost.
                if st.st_mode & (stat.S_ISUID | stat.S_ISGID):
                    os.chmod(full, stat.S_IMODE(st.st_mode) & ~(stat.S_ISUID | stat.S_ISGID))
                    findings.append(f"{domain}: stripped SUID/SGID on {full}")

                # Kill world-writable bits.
                if st.st_mode & stat.S_IWOTH:
                    new_mode = stat.S_IMODE(st.st_mode) & ~stat.S_IWOTH
                    os.chmod(full, new_mode)
                    findings.append(f"{domain}: removed world-writable bit on {full}")

                # Fix ownership drift (e.g. a careless upload as root/apache).
                if st.st_uid != expected_uid:
                    try:
                        os.chown(full, expected_uid, expected_uid)
                        findings.append(f"{domain}: fixed ownership on {full}")
                    except PermissionError:
                        pass

    if findings:
        db.log(actor, "harden_sweep", "*", "; ".join(findings[:200]))
    return findings
