"""
Authentication helpers.

Password hashing uses hashlib.scrypt (stdlib, no third-party crypto
dependency to audit or fall behind on patching). Sessions are signed
cookies (itsdangerous) - the session only ever stores the admin
username, never anything sensitive.
"""
import hashlib
import os
import secrets
import contextlib
from . import db

SCRYPT_N = 2 ** 14
SCRYPT_R = 8
SCRYPT_P = 1
KEY_LEN = 64


def _hash(password: str, salt: bytes) -> str:
    derived = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
        dklen=KEY_LEN,
    )
    return derived.hex()


def create_admin(username: str, password: str):
    salt = secrets.token_bytes(16)
    pw_hash = _hash(password, salt)
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "INSERT INTO admins (username, password_hash, salt) VALUES (?,?,?)",
            (username, pw_hash, salt.hex()),
        )
        conn.commit()


def verify_login(username: str, password: str) -> bool:
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute(
            "SELECT password_hash, salt FROM admins WHERE username = ?",
            (username,),
        ).fetchone()
    if not row:
        # Still run a hash to avoid leaking existence via timing.
        _hash(password, os.urandom(16))
        return False
    salt = bytes.fromhex(row["salt"])
    candidate = _hash(password, salt)
    return secrets.compare_digest(candidate, row["password_hash"])


def any_admin_exists() -> bool:
    with contextlib.closing(db.get_conn()) as conn:
        row = conn.execute("SELECT COUNT(*) AS c FROM admins").fetchone()
    return row["c"] > 0


def change_password(username: str, new_password: str):
    salt = secrets.token_bytes(16)
    pw_hash = _hash(new_password, salt)
    with contextlib.closing(db.get_conn()) as conn:
        conn.execute(
            "UPDATE admins SET password_hash=?, salt=? WHERE username=?",
            (pw_hash, salt.hex(), username),
        )
        conn.commit()
