"""
HostPanel - main FastAPI application.

Runs bound to 127.0.0.1 only; Apache terminates TLS and reverse-proxies
to this process (see installer/install.sh + systemd/hostpanel.service).
"""
import os
import secrets
import contextlib

from fastapi import FastAPI, Request, Form, UploadFile, File, HTTPException, Depends
from fastapi.responses import RedirectResponse, HTMLResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware

from . import config, db, auth, security, filemanager, dns_manager, mail_manager, ftp_manager, database_manager, tls_manager

BASE_DIR = os.path.dirname(__file__)

db.init_db()
os.makedirs(config.PANEL_ETC, exist_ok=True)
if not os.path.exists(config.SECRET_KEY_PATH):
    with open(config.SECRET_KEY_PATH, "w") as f:
        f.write(secrets.token_hex(32))
    os.chmod(config.SECRET_KEY_PATH, 0o600)
with open(config.SECRET_KEY_PATH) as f:
    SECRET_KEY = f.read().strip()

app = FastAPI(title="HostPanel")
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY, https_only=True, same_site="lax")
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))


# ---------------------------------------------------------------------
# Auth plumbing
# ---------------------------------------------------------------------

def current_user(request: Request):
    return request.session.get("user")


def require_login(request: Request):
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=303, headers={"Location": "/login"})
    return user


def csrf_token(request: Request) -> str:
    tok = request.session.get("csrf")
    if not tok:
        tok = secrets.token_hex(16)
        request.session["csrf"] = tok
    return tok


def check_csrf(request: Request, token: str):
    if not token or token != request.session.get("csrf"):
        raise HTTPException(status_code=403, detail="Invalid CSRF token")


@app.exception_handler(HTTPException)
async def auth_redirect(request: Request, exc: HTTPException):
    if exc.status_code == 303 and "Location" in (exc.headers or {}):
        return RedirectResponse(exc.headers["Location"], status_code=303)
    return PlainTextResponse(str(exc.detail), status_code=exc.status_code)


# ---------------------------------------------------------------------
# First-run setup + login
# ---------------------------------------------------------------------

@app.get("/setup", response_class=HTMLResponse)
def setup_get(request: Request):
    if auth.any_admin_exists():
        return RedirectResponse("/login")
    return templates.TemplateResponse("setup.html", {"request": request})


@app.post("/setup")
def setup_post(request: Request, username: str = Form(...), password: str = Form(...)):
    if auth.any_admin_exists():
        return RedirectResponse("/login", status_code=303)
    if len(password) < 12:
        return templates.TemplateResponse(
            "setup.html", {"request": request, "error": "Password must be at least 12 characters."}
        )
    auth.create_admin(username, password)
    db.log(username, "admin_created")
    return RedirectResponse("/login", status_code=303)


@app.get("/login", response_class=HTMLResponse)
def login_get(request: Request):
    if not auth.any_admin_exists():
        return RedirectResponse("/setup")
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/login")
def login_post(request: Request, username: str = Form(...), password: str = Form(...)):
    if auth.verify_login(username, password):
        request.session["user"] = username
        db.log(username, "login_success")
        return RedirectResponse("/dashboard", status_code=303)
    db.log(username, "login_failed")
    return templates.TemplateResponse(
        "login.html", {"request": request, "error": "Invalid username or password."}, status_code=401
    )


@app.get("/logout")
def logout(request: Request):
    user = current_user(request)
    request.session.clear()
    if user:
        db.log(user, "logout")
    return RedirectResponse("/login", status_code=303)


# ---------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------

@app.get("/", response_class=HTMLResponse)
def root(request: Request):
    return RedirectResponse("/dashboard")


@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request, user=Depends(require_login)):
    with contextlib.closing(db.get_conn()) as conn:
        domains = conn.execute("SELECT * FROM domains ORDER BY created_at DESC").fetchall()
        recent = conn.execute("SELECT * FROM audit_log ORDER BY id DESC LIMIT 15").fetchall()
    return templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user, "domains": domains, "recent": recent,
        "csrf": csrf_token(request), "active": "dashboard",
        "server_ip_set": bool(db.get_setting("server_ip")),
    })


# ---------------------------------------------------------------------
# Domains
# ---------------------------------------------------------------------

@app.get("/domains/new", response_class=HTMLResponse)
def domain_new_form(request: Request, user=Depends(require_login)):
    return templates.TemplateResponse("domain_new.html", {"request": request, "csrf": csrf_token(request)})


@app.post("/domains/new")
def domain_new(request: Request, domain: str = Form(...), csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        security.create_domain(domain, actor=user)
    except security.ProvisionError as e:
        return templates.TemplateResponse(
            "domain_new.html", {"request": request, "error": str(e), "csrf": csrf_token(request)}
        )
    return RedirectResponse("/dashboard", status_code=303)


@app.post("/domains/{domain}/delete")
def domain_delete(request: Request, domain: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    security.delete_domain(domain, actor=user)
    return RedirectResponse("/dashboard", status_code=303)


@app.post("/domains/{domain}/suspend")
def domain_suspend(request: Request, domain: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    security.suspend_domain(domain, actor=user)
    return RedirectResponse("/dashboard", status_code=303)


# ---------------------------------------------------------------------
# File manager
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/files", response_class=HTMLResponse)
def files_list(request: Request, domain: str, path: str = "", user=Depends(require_login)):
    try:
        entries = filemanager.list_dir(domain, path)
    except filemanager.FileAccessError as e:
        raise HTTPException(400, str(e))
    parent = "/".join(path.strip("/").split("/")[:-1]) if path.strip("/") else None
    return templates.TemplateResponse("files.html", {
        "request": request, "domain": domain, "path": path.strip("/"),
        "entries": entries, "parent": parent, "csrf": csrf_token(request),
    })


@app.get("/domains/{domain}/files/edit", response_class=HTMLResponse)
def file_edit_get(request: Request, domain: str, path: str, user=Depends(require_login)):
    try:
        content = filemanager.read_file(domain, path)
    except filemanager.FileAccessError as e:
        raise HTTPException(400, str(e))
    return templates.TemplateResponse("file_edit.html", {
        "request": request, "domain": domain, "path": path, "content": content,
        "csrf": csrf_token(request),
    })


@app.post("/domains/{domain}/files/edit")
def file_edit_post(request: Request, domain: str, path: str = Form(...),
                    content: str = Form(...), csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        filemanager.write_file(domain, path, content)
    except filemanager.FileAccessError as e:
        raise HTTPException(400, str(e))
    parent = "/".join(path.strip("/").split("/")[:-1])
    return RedirectResponse(f"/domains/{domain}/files?path={parent}", status_code=303)


@app.post("/domains/{domain}/files/upload")
def file_upload(request: Request, domain: str, path: str = Form(""),
                 csrf: str = Form(...), upload: UploadFile = File(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        filemanager.save_upload(domain, path, upload.filename, upload.file)
    except filemanager.FileAccessError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/files?path={path}", status_code=303)


@app.post("/domains/{domain}/files/mkdir")
def file_mkdir(request: Request, domain: str, path: str = Form(""), name: str = Form(...),
                csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        filemanager.make_dir(domain, os.path.join(path, name))
    except (filemanager.FileAccessError, FileExistsError) as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/files?path={path}", status_code=303)


@app.post("/domains/{domain}/files/delete")
def file_delete(request: Request, domain: str, path: str = Form(...),
                 csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        filemanager.delete_path(domain, path)
    except filemanager.FileAccessError as e:
        raise HTTPException(400, str(e))
    parent = "/".join(path.strip("/").split("/")[:-1])
    return RedirectResponse(f"/domains/{domain}/files?path={parent}", status_code=303)


# ---------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------

@app.get("/settings", response_class=HTMLResponse)
def settings_get(request: Request, user=Depends(require_login)):
    return templates.TemplateResponse("settings.html", {
        "request": request, "csrf": csrf_token(request), "active": "settings",
        "server_ip": db.get_setting("server_ip", ""),
        "admin_email": db.get_setting("admin_email", ""),
    })


@app.post("/settings")
def settings_post(request: Request, server_ip: str = Form(...), admin_email: str = Form(""),
                   csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    db.set_setting("server_ip", server_ip.strip())
    db.set_setting("admin_email", admin_email.strip())
    db.log(user, "settings_update", "server_ip", server_ip.strip())
    return RedirectResponse("/settings", status_code=303)


# ---------------------------------------------------------------------
# DNS
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/dns", response_class=HTMLResponse)
def dns_page(request: Request, domain: str, user=Depends(require_login)):
    records = dns_manager.list_records(domain)
    return templates.TemplateResponse("dns.html", {
        "request": request, "domain": domain, "records": records, "csrf": csrf_token(request),
    })


@app.post("/domains/{domain}/dns/add")
def dns_add(request: Request, domain: str, type: str = Form(...), name: str = Form(...),
            value: str = Form(...), priority: int = Form(0), ttl: int = Form(3600),
            csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        dns_manager.add_record(domain, type, name, value, priority, ttl, actor=user)
    except dns_manager.DnsError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/dns", status_code=303)


@app.post("/domains/{domain}/dns/{record_id}/delete")
def dns_delete(request: Request, domain: str, record_id: int, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        dns_manager.delete_record(domain, record_id, actor=user)
    except dns_manager.DnsError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/dns", status_code=303)


# ---------------------------------------------------------------------
# Mail
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/mail", response_class=HTMLResponse)
def mail_page(request: Request, domain: str, user=Depends(require_login)):
    enabled = mail_manager.mail_enabled(domain)
    mailboxes = mail_manager.list_mailboxes(domain) if enabled else []
    aliases = mail_manager.list_aliases(domain) if enabled else []
    return templates.TemplateResponse("mail.html", {
        "request": request, "domain": domain, "enabled": enabled,
        "mailboxes": mailboxes, "aliases": aliases, "csrf": csrf_token(request),
    })


@app.post("/domains/{domain}/mail/enable")
def mail_enable(request: Request, domain: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.enable_mail(domain, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/disable")
def mail_disable(request: Request, domain: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.disable_mail(domain, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/mailboxes/new")
def mailbox_new(request: Request, domain: str, local_part: str = Form(...), password: str = Form(...),
                quota_mb: int = Form(1024), csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.create_mailbox(domain, local_part, password, quota_mb, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/mailboxes/{local_part}/delete")
def mailbox_delete(request: Request, domain: str, local_part: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.delete_mailbox(domain, local_part, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/mailboxes/{local_part}/password")
def mailbox_password(request: Request, domain: str, local_part: str, password: str = Form(...),
                      csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.change_mailbox_password(domain, local_part, password, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/aliases/new")
def alias_new(request: Request, domain: str, source_local: str = Form(...), destination: str = Form(...),
              csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.create_alias(domain, source_local, destination, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


@app.post("/domains/{domain}/mail/aliases/{alias_id}/delete")
def alias_delete(request: Request, domain: str, alias_id: int, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        mail_manager.delete_alias(alias_id, domain, actor=user)
    except mail_manager.MailError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/mail", status_code=303)


# ---------------------------------------------------------------------
# FTP
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/ftp", response_class=HTMLResponse)
def ftp_page(request: Request, domain: str, user=Depends(require_login)):
    accounts = ftp_manager.list_accounts(domain)
    return templates.TemplateResponse("ftp.html", {
        "request": request, "domain": domain, "accounts": accounts, "csrf": csrf_token(request),
    })


@app.post("/domains/{domain}/ftp/{username}/password")
def ftp_set_password(request: Request, domain: str, username: str, password: str = Form(...),
                      csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        ftp_manager.set_password(domain, username, password, actor=user)
    except ftp_manager.FtpError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/ftp", status_code=303)


@app.post("/domains/{domain}/ftp/new")
def ftp_new_subaccount(request: Request, domain: str, label: str = Form(...), subpath: str = Form(""),
                        password: str = Form(...), csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        ftp_manager.create_subaccount(domain, label, subpath, password, actor=user)
    except ftp_manager.FtpError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/ftp", status_code=303)


@app.post("/domains/{domain}/ftp/{username}/delete")
def ftp_delete_subaccount(request: Request, domain: str, username: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        ftp_manager.delete_subaccount(domain, username, actor=user)
    except ftp_manager.FtpError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/ftp", status_code=303)


# ---------------------------------------------------------------------
# Databases
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/databases", response_class=HTMLResponse)
def databases_page(request: Request, domain: str, user=Depends(require_login)):
    databases = database_manager.list_databases(domain)
    return templates.TemplateResponse("databases.html", {
        "request": request, "domain": domain, "databases": databases, "csrf": csrf_token(request),
    })


@app.post("/domains/{domain}/databases/new")
def databases_new(request: Request, domain: str, label: str = Form(...), csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        database_manager.create_database(domain, label, actor=user)
    except database_manager.DatabaseError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/databases", status_code=303)


@app.post("/domains/{domain}/databases/{db_name}/regenerate")
def databases_regenerate(request: Request, domain: str, db_name: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        database_manager.regenerate_password(domain, db_name, actor=user)
    except database_manager.DatabaseError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/databases", status_code=303)


@app.post("/domains/{domain}/databases/{db_name}/delete")
def databases_delete(request: Request, domain: str, db_name: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    try:
        database_manager.delete_database(domain, db_name, actor=user)
    except database_manager.DatabaseError as e:
        raise HTTPException(400, str(e))
    return RedirectResponse(f"/domains/{domain}/databases", status_code=303)


# ---------------------------------------------------------------------
# TLS (Let's Encrypt)
# ---------------------------------------------------------------------

@app.get("/domains/{domain}/ssl", response_class=HTMLResponse)
def ssl_page(request: Request, domain: str, user=Depends(require_login)):
    return templates.TemplateResponse("ssl.html", {
        "request": request, "domain": domain, "csrf": csrf_token(request),
        "has_cert": tls_manager.certificate_exists(domain),
        "expiry": tls_manager.certificate_expiry(domain),
        "admin_email_set": bool(db.get_setting("admin_email")),
    })


@app.post("/domains/{domain}/ssl/issue")
def ssl_issue(request: Request, domain: str, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    error = None
    try:
        tls_manager.request_certificate(domain, actor=user)
    except tls_manager.TlsError as e:
        error = str(e)
    return templates.TemplateResponse("ssl.html", {
        "request": request, "domain": domain, "csrf": csrf_token(request),
        "has_cert": tls_manager.certificate_exists(domain),
        "expiry": tls_manager.certificate_expiry(domain),
        "admin_email_set": bool(db.get_setting("admin_email")),
        "error": error,
    })


# ---------------------------------------------------------------------
# Security center - lets the admin *see* the hardening happening
# ---------------------------------------------------------------------

@app.get("/security", response_class=HTMLResponse)
def security_center(request: Request, user=Depends(require_login)):
    with contextlib.closing(db.get_conn()) as conn:
        sweeps = conn.execute(
            "SELECT * FROM audit_log WHERE action='harden_sweep' ORDER BY id DESC LIMIT 20"
        ).fetchall()
    return templates.TemplateResponse("security.html", {
        "request": request, "sweeps": sweeps, "csrf": csrf_token(request), "active": "security",
    })


@app.post("/security/run-sweep-now")
def run_sweep_now(request: Request, csrf: str = Form(...), user=Depends(require_login)):
    check_csrf(request, csrf)
    security.harden_all(actor=user)
    return RedirectResponse("/security", status_code=303)
