"""
HostPanel configuration.
All filesystem paths and system-level constants live here so the rest
of the codebase never hardcodes a path inline.
"""
import os

# --- Base paths -------------------------------------------------------
VHOSTS_ROOT = "/var/www/vhosts"          # every domain gets a subfolder here
PANEL_ROOT = "/opt/hostpanel"
PANEL_ETC = "/etc/hostpanel"
PANEL_LOG = "/var/log/hostpanel"
DB_PATH = os.path.join(PANEL_ETC, "hostpanel.db")
SECRET_KEY_PATH = os.path.join(PANEL_ETC, "secret.key")

# --- Web server integration --------------------------------------------
APACHE_VHOST_DIR = "/etc/httpd/conf.d/vhosts"
PHP_FPM_POOL_DIR = "/etc/php-fpm.d"
PHP_FPM_SOCK_DIR = "/run/php-fpm"
APACHE_USER = "apache"
APACHE_GROUP = "apache"

# --- Security defaults --------------------------------------------------
# Functions disabled inside every domain's PHP-FPM pool. This is the
# single biggest lever against "bad WordPress plugin" style compromises:
# even if attacker-controlled PHP runs, it cannot shell out, read
# arbitrary files outside the vhost, or pivot to other domains.
PHP_DISABLED_FUNCTIONS = (
    "exec,passthru,shell_exec,system,proc_open,popen,curl_multi_exec,"
    "parse_ini_file,show_source,pcntl_exec,pcntl_fork,dl,"
    "posix_kill,posix_mkfifo,posix_setpgid,posix_setsid,posix_setuid"
)

# Directories inside a vhost where PHP execution is force-disabled at the
# Apache layer regardless of what the site owner uploads there. These are
# the classic upload/cache directories abused by web-shell attacks.
NO_PHP_EXEC_SUBDIRS = (
    "httpdocs/wp-content/uploads",
    "httpdocs/uploads",
    "httpdocs/images",
    "httpdocs/media",
    "httpdocs/cache",
    "httpdocs/tmp",
    "tmp",
)

# Minimum uid for domain system accounts, to keep them out of the way of
# real human/service accounts.
DOMAIN_UID_MIN = 20000

# How often (minutes) the permission-hardening sweep runs via systemd timer.
HARDEN_INTERVAL_MINUTES = 10

# File manager limits
MAX_UPLOAD_MB = 512
MAX_EDIT_FILE_MB = 5  # files bigger than this can be uploaded/downloaded but not opened in the text editor

# ======================================================================
# Stage 2: DNS + Mail
# ======================================================================

# --- DNS (BIND) ---------------------------------------------------------
BIND_ZONE_DIR = "/var/named/hostpanel"
BIND_INCLUDE_FILE = "/etc/named/hostpanel-zones.conf"
DEFAULT_TTL = 3600
DEFAULT_SOA_REFRESH = 3600
DEFAULT_SOA_RETRY = 900
DEFAULT_SOA_EXPIRE = 604800
DEFAULT_SOA_MINTTL = 3600

# --- Mail (Postfix + Dovecot + OpenDKIM) --------------------------------
# Postfix and Dovecot query hostpanel.db (SQLite) directly via their
# built-in sqlite map/driver support - no separate mail database to keep
# in sync with the panel's own mail_domains/mail_users/mail_aliases tables.
MAIL_VHOST_BASE = "/var/mail/vhosts"      # maildir storage, outside any web-servable path
VMAIL_USER = "vmail"
VMAIL_UID = 5000
VMAIL_GID = 5000

DKIM_KEY_DIR = "/etc/opendkim/keys"
DKIM_SELECTOR = "default"

MAX_MAILBOXES_PER_DOMAIN = 500  # sane ceiling; raise per-domain later if needed

# --- Webmail (Roundcube) -------------------------------------------------
# Roundcube's own application data (address books, UI prefs - never mail
# content) lives in its own small MariaDB database; Roundcube itself
# authenticates end users straight to Dovecot IMAP with the credentials
# they type in, so it never needs access to hostpanel.db.
ROUNDCUBE_DIR = "/opt/roundcube"
ROUNDCUBE_USER = "hproundcube"
ROUNDCUBE_DB_NAME = "roundcubemail"
ROUNDCUBE_DB_USER = "roundcube"
ROUNDCUBE_DB_CRED_PATH = "/etc/hostpanel/roundcube_db_credentials"
ROUNDCUBE_FPM_SOCK = "/run/php-fpm/roundcube.sock"

# ======================================================================
# Stage 3: FTP + per-domain databases
# ======================================================================

# --- FTP (ProFTPD) -------------------------------------------------------
# ProFTPD authenticates against hostpanel.db directly (mod_sql + sqlite3
# backend), same pattern as Stage 2's mail integration - one source of
# truth, no separate account store to keep in sync.
FTP_HASH_SCHEME = "SHA512-CRYPT"   # what ProFTPD's "Crypt" SQLAuthType expects
MAX_FTP_SUBACCOUNTS_PER_DOMAIN = 20

# --- Per-domain MariaDB databases ----------------------------------------
DB_ROOT_PASSWORD_FILE = "/root/.hostpanel/db_root_password"  # written by installer/install.sh
MYSQL_SOCKET = "/var/lib/mysql/mysql.sock"
MAX_DATABASES_PER_DOMAIN = 20
DB_NAME_MAX_LEN = 64     # MySQL/MariaDB identifier limit
DB_USER_MAX_LEN = 32     # MySQL/MariaDB username limit (older versions)

