#!/opt/hostpanel/venv/bin/python
"""Entry point invoked by the systemd timer to run the permission sweep."""
import sys
sys.path.insert(0, "/opt/hostpanel")
from app import security

if __name__ == "__main__":
    findings = security.harden_all(actor="hostpanel-harden.timer")
    if findings:
        print(f"Repaired {len(findings)} issue(s):")
        for f in findings:
            print(" -", f)
    else:
        print("No drift found.")
