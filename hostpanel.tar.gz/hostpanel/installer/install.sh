#!/usr/bin/env bash
#
# HostPanel installer - AlmaLinux 10, standalone, no license/activation.
#
# Installs and wires together: Apache (httpd) + PHP-FPM, MariaDB,
# firewalld, fail2ban, and the HostPanel control panel itself, then
# provisions a hardened baseline so newly-created domains are isolated
# from each other by default.
#
# Run as root on a fresh AlmaLinux 10 server:
#   curl -fsSL .../install.sh -o install.sh && sudo bash install.sh
#
set -euo pipefail

LOG=/var/log/hostpanel-install.log
exec > >(tee -a "$LOG") 2>&1

PANEL_SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"   # repo root (contains app/, scripts/, systemd/)
PANEL_HOME=/opt/hostpanel
PANEL_ETC=/etc/hostpanel
VHOSTS_ROOT=/var/www/vhosts
PANEL_PORT=5000
PANEL_HTTPS_PORT=8443

c_green() { printf "\033[32m%s\033[0m\n" "$1"; }
c_red()   { printf "\033[31m%s\033[0m\n" "$1"; }
c_blue()  { printf "\033[34m%s\033[0m\n" "$1"; }

require_root() {
  if [[ $EUID -ne 0 ]]; then
    c_red "Run this installer as root (sudo bash install.sh)."
    exit 1
  fi
}

require_almalinux10() {
  if [[ ! -f /etc/almalinux-release ]] || ! grep -q "release 10" /etc/almalinux-release; then
    c_red "This installer targets AlmaLinux 10. Detected:"
    cat /etc/os-release 2>/dev/null || true
    read -rp "Continue anyway? [y/N] " ans
    [[ "${ans,,}" == "y" ]] || exit 1
  fi
}

step() { c_blue "==> $1"; }

require_root
require_almalinux10

# ---------------------------------------------------------------------
step "Installing system packages"
# ---------------------------------------------------------------------
dnf -y install epel-release
dnf -y update
dnf -y install \
  httpd mod_ssl \
  mariadb-server mariadb \
  php php-fpm php-cli php-common php-mysqlnd php-gd php-mbstring php-xml php-opcache \
  firewalld fail2ban \
  policycoreutils-python-utils setroubleshoot-server \
  acl attr \
  python3 python3-pip python3-devel \
  openssl cronie git unzip tar rsync curl \
  httpd-tools

systemctl enable --now crond

# ---------------------------------------------------------------------
step "Hardening MariaDB and setting a random root password"
# ---------------------------------------------------------------------
systemctl enable --now mariadb
DB_ROOT_PASS="$(openssl rand -base64 24)"
mysql <<SQL
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASS}';
DELETE FROM mysql.user WHERE User='';
DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
FLUSH PRIVILEGES;
SQL
install -d -m 700 /root/.hostpanel
echo "$DB_ROOT_PASS" > /root/.hostpanel/db_root_password
chmod 600 /root/.hostpanel/db_root_password
c_green "MariaDB root password saved to /root/.hostpanel/db_root_password (root only)."

# ---------------------------------------------------------------------
step "Laying out vhosts root"
# ---------------------------------------------------------------------
install -d -m 711 "$VHOSTS_ROOT"     # traversal-only: apache/fpm can reach into a vhost dir, never list it

# ---------------------------------------------------------------------
step "Deploying HostPanel application"
# ---------------------------------------------------------------------
install -d -m 750 "$PANEL_HOME" "$PANEL_ETC"
rsync -a --delete "$PANEL_SRC_DIR/app/" "$PANEL_HOME/app/" 2>/dev/null || cp -r "$PANEL_SRC_DIR/app" "$PANEL_HOME/"
cp -r "$PANEL_SRC_DIR/scripts" "$PANEL_HOME/"
cp "$PANEL_SRC_DIR/requirements.txt" "$PANEL_HOME/"

python3 -m venv "$PANEL_HOME/venv"
"$PANEL_HOME/venv/bin/pip" install --upgrade pip
"$PANEL_HOME/venv/bin/pip" install -r "$PANEL_HOME/requirements.txt"

chown -R root:root "$PANEL_HOME" "$PANEL_ETC"
chmod 700 "$PANEL_ETC"

# ---------------------------------------------------------------------
step "Installing systemd units"
# ---------------------------------------------------------------------
cp "$PANEL_SRC_DIR/systemd/hostpanel.service" /etc/systemd/system/
cp "$PANEL_SRC_DIR/systemd/hostpanel-harden.service" /etc/systemd/system/
cp "$PANEL_SRC_DIR/systemd/hostpanel-harden.timer" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now hostpanel.service
systemctl enable --now hostpanel-harden.timer

# ---------------------------------------------------------------------
step "Generating a self-signed certificate for the panel (replace with a real one later)"
# ---------------------------------------------------------------------
install -d -m 700 /etc/hostpanel/ssl
openssl req -x509 -nodes -newkey rsa:2048 \
  -keyout /etc/hostpanel/ssl/panel.key \
  -out /etc/hostpanel/ssl/panel.crt \
  -days 825 \
  -subj "/CN=hostpanel" >/dev/null 2>&1
chmod 600 /etc/hostpanel/ssl/panel.key

# ---------------------------------------------------------------------
step "Configuring Apache reverse proxy for the panel UI (port ${PANEL_HTTPS_PORT})"
# ---------------------------------------------------------------------
mkdir -p /etc/httpd/conf.d/vhosts
cat > /etc/httpd/conf.d/hostpanel-ui.conf <<EOF
Listen ${PANEL_HTTPS_PORT} https
<VirtualHost *:${PANEL_HTTPS_PORT}>
    ServerName hostpanel
    SSLEngine on
    SSLCertificateFile /etc/hostpanel/ssl/panel.crt
    SSLCertificateKeyFile /etc/hostpanel/ssl/panel.key

    ProxyPreserveHost On
    ProxyPass "/" "http://127.0.0.1:${PANEL_PORT}/"
    ProxyPassReverse "/" "http://127.0.0.1:${PANEL_PORT}/"

    Header always set Strict-Transport-Security "max-age=15552000; includeSubDomains"
    Header always set X-Content-Type-Options "nosniff"
    Header always set X-Frame-Options "SAMEORIGIN"
</VirtualHost>
EOF

# Make sure the base httpd.conf includes conf.d/*.conf and mod_proxy is loaded (default on AlmaLinux).
sed -i 's/^Listen 80$/Listen 80/' /etc/httpd/conf/httpd.conf || true

# ---------------------------------------------------------------------
step "SELinux: labeling vhosts and allowing the proxy to reach the panel"
# ---------------------------------------------------------------------
setsebool -P httpd_can_network_connect on
semanage fcontext -a -t httpd_sys_rw_content_t "${VHOSTS_ROOT}(/.*)?" 2>/dev/null || \
  semanage fcontext -m -t httpd_sys_rw_content_t "${VHOSTS_ROOT}(/.*)?"
restorecon -R "$VHOSTS_ROOT" || true

# ---------------------------------------------------------------------
step "Configuring firewall"
# ---------------------------------------------------------------------
systemctl enable --now firewalld
firewall-cmd --permanent --add-service=http
firewall-cmd --permanent --add-service=https
firewall-cmd --permanent --add-port=${PANEL_HTTPS_PORT}/tcp
firewall-cmd --reload

# ---------------------------------------------------------------------
step "Configuring fail2ban for Apache and the panel login"
# ---------------------------------------------------------------------
cat > /etc/fail2ban/jail.d/hostpanel.local <<'EOF'
[apache-auth]
enabled = true

[apache-badbots]
enabled = true

[hostpanel-login]
enabled = true
port    = http,https,8443
filter  = hostpanel-login
logpath = /var/www/vhosts/*/logs/access.log
          /var/log/httpd/*access_log
maxretry = 6
findtime = 600
bantime  = 3600
EOF

cat > /etc/fail2ban/filter.d/hostpanel-login.conf <<'EOF'
[Definition]
failregex = ^<HOST> .* "POST /login HTTP/.*" 401
ignoreregex =
EOF

systemctl enable --now fail2ban

# ---------------------------------------------------------------------
step "Restarting web services"
# ---------------------------------------------------------------------
systemctl enable --now httpd
systemctl enable --now php-fpm
apachectl configtest && systemctl restart httpd

# ---------------------------------------------------------------------
IP="$(curl -s -4 ifconfig.me || hostname -I | awk '{print $1}')"
echo
c_green "============================================================"
c_green " HostPanel installed."
c_green "============================================================"
echo "  Panel URL:      https://${IP}:${PANEL_HTTPS_PORT}/setup"
echo "  (self-signed certificate - your browser will warn once; replace"
echo "   /etc/hostpanel/ssl/panel.{crt,key} with a real certificate when ready)"
echo
echo "  MariaDB root password: /root/.hostpanel/db_root_password (root-readable only)"
echo "  Install log:            $LOG"
echo
echo "  Next: open the panel URL above and create your admin account."
c_green "============================================================"
