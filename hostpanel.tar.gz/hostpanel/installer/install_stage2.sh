#!/usr/bin/env bash
#
# HostPanel Stage 2 installer - DNS (BIND) + Mail (Postfix/Dovecot/
# OpenDKIM) + Webmail (Roundcube).
#
# Run AFTER installer/install.sh (Stage 1) has completed successfully
# on the same AlmaLinux 10 server.
#
set -euo pipefail

LOG=/var/log/hostpanel-install-stage2.log
exec > >(tee -a "$LOG") 2>&1

PANEL_HOME=/opt/hostpanel
PANEL_ETC=/etc/hostpanel
DB_PATH="$PANEL_ETC/hostpanel.db"
MAIL_BASE=/var/mail/vhosts
VMAIL_UID=5000
VMAIL_GID=5000

c_green() { printf "\033[32m%s\033[0m\n" "$1"; }
c_red()   { printf "\033[31m%s\033[0m\n" "$1"; }
c_blue()  { printf "\033[34m%s\033[0m\n" "$1"; }
step()    { c_blue "==> $1"; }

if [[ $EUID -ne 0 ]]; then
  c_red "Run as root."
  exit 1
fi

if [[ ! -d "$PANEL_HOME" ]]; then
  c_red "HostPanel Stage 1 doesn't appear to be installed ($PANEL_HOME missing). Run installer/install.sh first."
  exit 1
fi

# ---------------------------------------------------------------------
step "Installing packages: BIND, Postfix, Dovecot, OpenDKIM, and PHP extensions Roundcube needs"
# ---------------------------------------------------------------------
dnf -y install \
  bind bind-utils \
  postfix \
  dovecot \
  opendkim \
  php-imap php-intl php-zip php-pspell \
  || true

# Some distro layouts ship the SQL driver support for Dovecot as
# separate sub-packages; try, but don't fail the whole install if the
# package name differs on your mirror - see README "Known limitations".
dnf -y install dovecot-pgsql dovecot-mysql 2>/dev/null || true

# Make sure Postfix, not sendmail, is the active MTA.
command -v alternatives >/dev/null 2>&1 && alternatives --set mta /usr/sbin/sendmail.postfix 2>/dev/null || true

# ---------------------------------------------------------------------
step "Applying the Stage 2 database schema (DNS + mail tables)"
# ---------------------------------------------------------------------
# The panel app itself creates these tables on next start (db.init_db()
# already includes them), but make sure hostpanel.service has been
# restarted at least once so they exist before Postfix/Dovecot query them.
systemctl restart hostpanel.service
sleep 2
if [[ ! -f "$DB_PATH" ]]; then
  c_red "hostpanel.db not found at $DB_PATH - is hostpanel.service running? Check 'systemctl status hostpanel'."
  exit 1
fi

# ---------------------------------------------------------------------
step "Creating the vmail system account and mail storage root"
# ---------------------------------------------------------------------
if ! id vmail &>/dev/null; then
  groupadd -g "$VMAIL_GID" vmail
  useradd -u "$VMAIL_UID" -g vmail -d "$MAIL_BASE" -s /sbin/nologin -c "hostpanel:virtual mail" vmail
fi
install -d -m 700 -o vmail -g vmail "$MAIL_BASE"

# ---------------------------------------------------------------------
step "Configuring BIND (named) to serve HostPanel-managed zones"
# ---------------------------------------------------------------------
install -d -m 755 -o named -g named /var/named/hostpanel 2>/dev/null || install -d -m 755 /var/named/hostpanel
touch /etc/named/hostpanel-zones.conf
if ! grep -q 'hostpanel-zones.conf' /etc/named.conf 2>/dev/null; then
  sed -i '/^};/i \\ninclude "/etc/named/hostpanel-zones.conf";' /etc/named.conf || \
    echo 'include "/etc/named/hostpanel-zones.conf";' >> /etc/named.conf
fi
# Allow the world to query (this is authoritative public DNS, not a resolver).
sed -i 's/allow-query\s*{\s*localhost;\s*};/allow-query { any; };/' /etc/named.conf || true
named-checkconf || c_red "named-checkconf reported an issue - check /etc/named.conf manually before relying on DNS."
systemctl enable --now named

# ---------------------------------------------------------------------
step "Wiring Postfix to hostpanel.db via its built-in SQLite maps"
# ---------------------------------------------------------------------
cat > /etc/postfix/sqlite-virtual-mailbox-domains.cf <<EOF
dbpath = $DB_PATH
query = SELECT 1 FROM mail_domains WHERE domain='%s'
EOF

cat > /etc/postfix/sqlite-virtual-mailbox-maps.cf <<EOF
dbpath = $DB_PATH
query = SELECT 1 FROM mail_users WHERE email='%s' AND status='active'
EOF

cat > /etc/postfix/sqlite-virtual-alias-maps.cf <<EOF
dbpath = $DB_PATH
query = SELECT destination FROM mail_aliases WHERE source='%s'
EOF
chmod 640 /etc/postfix/sqlite-virtual-*.cf
chgrp postfix /etc/postfix/sqlite-virtual-*.cf

HOSTNAME_FQDN="$(hostname -f 2>/dev/null || hostname)"

postconf -e "myhostname = ${HOSTNAME_FQDN}"
postconf -e "mydestination = localhost"
postconf -e "virtual_mailbox_domains = sqlite:/etc/postfix/sqlite-virtual-mailbox-domains.cf"
postconf -e "virtual_mailbox_maps = sqlite:/etc/postfix/sqlite-virtual-mailbox-maps.cf"
postconf -e "virtual_alias_maps = sqlite:/etc/postfix/sqlite-virtual-alias-maps.cf"
postconf -e "virtual_mailbox_base = ${MAIL_BASE}"
postconf -e "virtual_uid_maps = static:${VMAIL_UID}"
postconf -e "virtual_gid_maps = static:${VMAIL_GID}"
postconf -e "virtual_transport = lmtp:unix:private/dovecot-lmtp"

postconf -e "smtpd_sasl_type = dovecot"
postconf -e "smtpd_sasl_path = private/auth"
postconf -e "smtpd_sasl_auth_enable = yes"
postconf -e "smtpd_relay_restrictions = permit_sasl_authenticated,permit_mynetworks,reject_unauth_destination"
postconf -e "smtpd_recipient_restrictions = permit_sasl_authenticated,permit_mynetworks,reject_unauth_destination,reject_unknown_recipient_domain"

postconf -e "smtpd_tls_cert_file = /etc/hostpanel/ssl/panel.crt"
postconf -e "smtpd_tls_key_file = /etc/hostpanel/ssl/panel.key"
postconf -e "smtpd_tls_security_level = may"
postconf -e "smtp_tls_security_level = may"

postconf -e "milter_default_action = accept"
postconf -e "milter_protocol = 6"
postconf -e "smtpd_milters = inet:127.0.0.1:8891"
postconf -e "non_smtpd_milters = inet:127.0.0.1:8891"

# Enable the submission (587) and smtps (465) services with mandatory auth.
python3 - "$0" <<'PYEOF'
import re
path = "/etc/postfix/master.cf"
with open(path) as f:
    content = f.read()

def ensure_service(content, block_name, block):
    if re.search(rf"^{re.escape(block_name)}", content, re.MULTILINE):
        return content
    return content.rstrip("\n") + "\n\n" + block + "\n"

submission_block = """submission inet n       -       n       -       -       smtpd
  -o syslog_name=postfix/submission
  -o smtpd_tls_security_level=encrypt
  -o smtpd_sasl_auth_enable=yes
  -o smtpd_relay_restrictions=permit_sasl_authenticated,reject
  -o smtpd_recipient_restrictions=permit_sasl_authenticated,reject"""

smtps_block = """smtps     inet  n       -       n       -       -       smtpd
  -o syslog_name=postfix/smtps
  -o smtpd_tls_wrappermode=yes
  -o smtpd_sasl_auth_enable=yes
  -o smtpd_relay_restrictions=permit_sasl_authenticated,reject
  -o smtpd_recipient_restrictions=permit_sasl_authenticated,reject"""

content = ensure_service(content, "submission inet", submission_block)
content = ensure_service(content, "smtps     inet", smtps_block)

with open(path, "w") as f:
    f.write(content)
PYEOF

# ---------------------------------------------------------------------
step "Wiring Dovecot to hostpanel.db and enabling LMTP delivery"
# ---------------------------------------------------------------------
cat > /etc/dovecot/dovecot-sql.conf.ext <<EOF
driver = sqlite
connect = ${DB_PATH}
default_pass_scheme = SSHA256
password_query = SELECT email AS user, password_hash AS password FROM mail_users WHERE email = '%u' AND status = 'active'
user_query = SELECT '${MAIL_BASE}/%d/%n' AS home, ${VMAIL_UID} AS uid, ${VMAIL_GID} AS gid, 'maildir:${MAIL_BASE}/%d/%n/Maildir' AS mail FROM mail_users WHERE email = '%u' AND status = 'active'
EOF
chmod 600 /etc/dovecot/dovecot-sql.conf.ext
chown root:dovecot /etc/dovecot/dovecot-sql.conf.ext

sed -i "s|^#\?mail_location.*|mail_location = maildir:${MAIL_BASE}/%d/%n/Maildir|" /etc/dovecot/conf.d/10-mail.conf

cat > /etc/dovecot/conf.d/auth-sql.conf.ext <<'EOF'
passdb {
  driver = sql
  args = /etc/dovecot/dovecot-sql.conf.ext
}
userdb {
  driver = sql
  args = /etc/dovecot/dovecot-sql.conf.ext
}
EOF
if ! grep -q 'auth-sql.conf.ext' /etc/dovecot/conf.d/10-auth.conf; then
  echo '!include auth-sql.conf.ext' >> /etc/dovecot/conf.d/10-auth.conf
fi
sed -i 's/^#\?disable_plaintext_auth.*/disable_plaintext_auth = yes/' /etc/dovecot/conf.d/10-auth.conf
sed -i 's/^auth_mechanisms.*/auth_mechanisms = plain login/' /etc/dovecot/conf.d/10-auth.conf

sed -i 's|^#\?ssl_cert.*|ssl_cert = </etc/hostpanel/ssl/panel.crt|' /etc/dovecot/conf.d/10-ssl.conf
sed -i 's|^#\?ssl_key.*|ssl_key = </etc/hostpanel/ssl/panel.key|' /etc/dovecot/conf.d/10-ssl.conf

# LMTP + SASL socket for Postfix.
cat >> /etc/dovecot/conf.d/10-master.conf <<'EOF'

service lmtp {
  unix_listener /var/spool/postfix/private/dovecot-lmtp {
    mode = 0600
    user = postfix
    group = postfix
  }
}
service auth {
  unix_listener /var/spool/postfix/private/auth {
    mode = 0660
    user = postfix
    group = postfix
  }
}
EOF

# ---------------------------------------------------------------------
step "Configuring OpenDKIM"
# ---------------------------------------------------------------------
install -d -m 750 -o opendkim -g opendkim /etc/opendkim/keys
touch /etc/opendkim/KeyTable /etc/opendkim/SigningTable
cat > /etc/opendkim/TrustedHosts <<EOF
127.0.0.1
localhost
::1
EOF

sed -i 's/^Mode.*/Mode                    sv/' /etc/opendkim.conf 2>/dev/null || echo "Mode sv" >> /etc/opendkim.conf
grep -q '^KeyTable' /etc/opendkim.conf || echo "KeyTable /etc/opendkim/KeyTable" >> /etc/opendkim.conf
grep -q '^SigningTable' /etc/opendkim.conf || echo "SigningTable refile:/etc/opendkim/SigningTable" >> /etc/opendkim.conf
grep -q '^ExternalIgnoreList' /etc/opendkim.conf || echo "ExternalIgnoreList refile:/etc/opendkim/TrustedHosts" >> /etc/opendkim.conf
grep -q '^InternalHosts' /etc/opendkim.conf || echo "InternalHosts refile:/etc/opendkim/TrustedHosts" >> /etc/opendkim.conf
grep -q '^Socket' /etc/opendkim.conf || echo "Socket inet:8891@127.0.0.1" >> /etc/opendkim.conf
sed -i 's|^Socket.*|Socket inet:8891@127.0.0.1|' /etc/opendkim.conf

# ---------------------------------------------------------------------
step "Deploying Roundcube webmail (own isolated PHP-FPM pool, like a domain)"
# ---------------------------------------------------------------------
if ! id hproundcube &>/dev/null; then
  useradd --system --home-dir /opt/roundcube --shell /sbin/nologin -c "hostpanel:webmail" hproundcube
fi

if [[ ! -d /opt/roundcube ]]; then
  RC_URL="$(curl -s https://api.github.com/repos/roundcube/roundcubemail/releases/latest \
            | grep browser_download_url | grep complete.tar.gz | head -1 | cut -d '"' -f4)"
  if [[ -z "$RC_URL" ]]; then
    c_red "Could not determine the latest Roundcube release URL automatically."
    c_red "Download a '-complete.tar.gz' release from https://github.com/roundcube/roundcubemail/releases"
    c_red "and extract it to /opt/roundcube, then re-run this script."
    exit 1
  fi
  curl -fsSL "$RC_URL" -o /tmp/roundcube.tar.gz
  mkdir -p /opt/roundcube
  tar -xzf /tmp/roundcube.tar.gz --strip-components=1 -C /opt/roundcube
  rm -f /tmp/roundcube.tar.gz
fi

RC_DB_PASS="$(openssl rand -base64 24)"
mysql <<SQL
CREATE DATABASE IF NOT EXISTS roundcubemail CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER IF NOT EXISTS 'roundcube'@'localhost' IDENTIFIED BY '${RC_DB_PASS}';
GRANT ALL PRIVILEGES ON roundcubemail.* TO 'roundcube'@'localhost';
FLUSH PRIVILEGES;
SQL
echo "$RC_DB_PASS" > /etc/hostpanel/roundcube_db_credentials
chmod 600 /etc/hostpanel/roundcube_db_credentials

if [[ -f /opt/roundcube/SQL/mysql.initial.sql ]]; then
  mysql roundcubemail < /opt/roundcube/SQL/mysql.initial.sql || true
fi

RC_DES_KEY="$(openssl rand -hex 12)"
cat > /opt/roundcube/config/config.inc.php <<EOF
<?php
\$config = [];
\$config['db_dsnw'] = 'mysql://roundcube:${RC_DB_PASS}@localhost/roundcubemail';
\$config['imap_host'] = 'tls://127.0.0.1:143';
\$config['smtp_host'] = 'tls://127.0.0.1:587';
\$config['smtp_user'] = '%u';
\$config['smtp_pass'] = '%p';
\$config['support_url'] = '';
\$config['product_name'] = 'Webmail';
\$config['des_key'] = '${RC_DES_KEY}';
\$config['plugins'] = ['archive', 'zipdownload'];
\$config['skin'] = 'elastic';
EOF

chown -R hproundcube:hproundcube /opt/roundcube
find /opt/roundcube -type d -exec chmod 750 {} \;
find /opt/roundcube -type f -exec chmod 640 {} \;
chmod 750 /opt/roundcube/bin/*.sh 2>/dev/null || true

cat > /etc/php-fpm.d/roundcube.conf <<EOF
[roundcube]
user = hproundcube
group = hproundcube
listen = /run/php-fpm/roundcube.sock
listen.owner = apache
listen.group = apache
listen.mode = 0660
pm = ondemand
pm.max_children = 6
php_admin_value[open_basedir] = /opt/roundcube:/tmp
php_admin_value[disable_functions] = exec,passthru,shell_exec,system,proc_open,popen
php_admin_flag[expose_php] = off
EOF

if ! grep -q "Alias /webmail" /etc/httpd/conf.d/hostpanel-ui.conf; then
  python3 - <<'PYEOF'
path = "/etc/httpd/conf.d/hostpanel-ui.conf"
with open(path) as f:
    content = f.read()
insertion = '''
    Alias /webmail /opt/roundcube
    <Directory "/opt/roundcube">
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
        <FilesMatch "\\.php$">
            SetHandler "proxy:unix:/run/php-fpm/roundcube.sock|fcgi://localhost"
        </FilesMatch>
    </Directory>
'''
content = content.replace("</VirtualHost>", insertion + "</VirtualHost>")
with open(path, "w") as f:
    f.write(content)
PYEOF
fi

# ---------------------------------------------------------------------
step "Opening firewall ports for DNS + mail"
# ---------------------------------------------------------------------
firewall-cmd --permanent --add-service=dns
firewall-cmd --permanent --add-service=smtp
firewall-cmd --permanent --add-port=587/tcp   # submission
firewall-cmd --permanent --add-port=465/tcp   # smtps
firewall-cmd --permanent --add-port=143/tcp   # imap (STARTTLS)
firewall-cmd --permanent --add-port=993/tcp   # imaps
firewall-cmd --reload

# ---------------------------------------------------------------------
step "SELinux adjustments"
# ---------------------------------------------------------------------
setsebool -P allow_postfix_local_write_mail_spool on 2>/dev/null || true
semanage fcontext -a -t mail_spool_t "${MAIL_BASE}(/.*)?" 2>/dev/null || \
  semanage fcontext -m -t mail_spool_t "${MAIL_BASE}(/.*)?"
restorecon -R "$MAIL_BASE" || true
setsebool -P httpd_can_network_connect on

# ---------------------------------------------------------------------
step "Starting services"
# ---------------------------------------------------------------------
postfix check
systemctl enable --now opendkim
systemctl enable --now dovecot
systemctl restart postfix
systemctl restart php-fpm
systemctl restart httpd

echo
c_green "============================================================"
c_green " Stage 2 installed: DNS, mail, and webmail are live."
c_green "============================================================"
echo "  Webmail:  https://<your-panel-host>:8443/webmail"
echo "  IMAP:     port 993 (IMAPS) or 143 (STARTTLS)"
echo "  SMTP:     port 587 (submission, STARTTLS) or 465 (SMTPS)"
echo "  DNS:      make sure your domain's registrar delegates to this"
echo "            server's ns1./ns2. records (see the domain's DNS page"
echo "            in the panel) - and set your server's public IP on"
echo "            the panel's Settings page if you haven't already."
echo
c_red "  Verify before trusting this in production:"
echo "   - dovecot -n   (confirm SQL auth loaded without errors)"
echo "   - postfix check && postconf -n | grep virtual_"
echo "   - send a test mail and check 'dig TXT default._domainkey.yourdomain'"
echo "     matches what the panel's DNS page shows for that domain"
c_green "============================================================"
