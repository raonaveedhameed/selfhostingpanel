# HostPanel

A self-hosted, license-free web hosting control panel for a standalone
AlmaLinux 10 server.

- **Stage 1** (`installer/install.sh`): domain hosting with automatic
  per-domain isolation (dedicated Linux user + PHP-FPM pool per domain)
  and a file manager.
- **Stage 2** (`installer/install_stage2.sh`): DNS (BIND) and mail
  (Postfix + Dovecot + OpenDKIM + Roundcube webmail), covered below.
- **Stage 3** (`installer/install_stage3.sh`): FTP (ProFTPD) and
  per-domain MariaDB databases, covered below.
- **Stage 4** (`installer/install_stage4.sh`): free, auto-renewing HTTPS
  certificates per domain via Let's Encrypt, covered below.

That's the full Plesk-equivalent feature set from the original ask, plus
the piece Plesk normally treats as a paid add-on (SSL used to be, and
sometimes still is, gated behind licensing tiers - here it's free by
construction, since it's just certbot).

## Why this exists / the actual security model

Plesk, cPanel, and similar panels get compromised most often not because
of a flaw in the panel itself, but because **all sites on the server
share one PHP execution context** (commonly `apache`/`www-data`, or a
loosely-configured suexec). A vulnerable WordPress plugin on Customer
A's site gets code execution as that shared user, and from there can
read Customer B's `wp-config.php`, write to Customer C's uploads folder,
or worse.

HostPanel's answer is architectural, not a setting the customer has to
remember to enable:

| Layer | What happens automatically |
|---|---|
| System user | Every domain gets its own Linux user (`nologin`, password login locked) - created the moment you click "Add domain" |
| PHP execution | Its own PHP-FPM pool, running **as that user**, not as `apache` |
| Filesystem | `open_basedir` locks PHP to its own vhost; nothing else on disk is even visible to it |
| Dangerous functions | `exec`, `shell_exec`, `system`, `proc_open`, `popen`, etc. disabled in every pool |
| Upload directories | PHP execution is force-disabled at the Apache layer inside `uploads/`, `wp-content/uploads/`, `cache/`, `tmp/` - the classic web-shell persistence spot, closed even if a file gets written there |
| Permissions | A systemd timer sweeps every vhost every 10 minutes, silently repairing world-writable files, stray SUID/SGID bits, ownership drift, and symlinks that try to escape the vhost |
| File manager | Every write/upload is immediately re-owned to the domain's own user and stripped of executable/world-writable bits |

This meaningfully contains a compromised plugin to the single site it
compromised. It does not make that site itself un-hackable - keeping
WordPress core/plugins updated is still the customer's job - but it stops
one bad plugin from taking down every other tenant on the box, which is
the actual pattern behind most "Plesk got hacked" stories.

**Be honest with yourself about the rest of the picture too:** this is a
young codebase, not a decade-hardened product. Treat Stage 1 as a strong
foundation, not a guarantee, and keep the server itself patched
(`dnf update`), keep an eye on `/var/log/hostpanel-install.log` and the
Security Center page, and don't expose the panel port to more people than
need it.

## Installing

On a fresh AlmaLinux 10 server, as root:

```bash
git clone <this-repo> hostpanel-src
cd hostpanel-src
bash installer/install.sh
```

The installer is idempotent-ish for re-runs (it won't be perfectly safe to
re-run blindly on a live server yet - see Roadmap - but on a fresh box
it's one shot, no prompts beyond an OS-version confirmation, no license
key, no phone-home). At the end it prints:

```
Panel URL:      https://<server-ip>:8443/setup
MariaDB root password: /root/.hostpanel/db_root_password
```

Open that URL, accept the self-signed certificate warning (replace the
cert in `/etc/hostpanel/ssl/` with a real one once you have a hostname +
Let's Encrypt set up - that's Stage 2 work), and create your admin
account. From there: **Add domain** provisions everything described
above in a few seconds.

## Stage 2: DNS + Mail

```bash
bash installer/install_stage2.sh
```

Run this after Stage 1 is installed and working. It installs BIND,
Postfix, Dovecot, OpenDKIM, and Roundcube, and wires them together with
the panel:

- **DNS is provisioned automatically.** The moment you add a domain in
  Stage 1, it now also gets a DNS zone (NS glue records + apex A + `www`
  CNAME), visible and editable on that domain's **DNS** page. Set your
  server's public IP once on the **Settings** page first - that's what
  the auto-generated A records point at.
- **Mail is opt-in per domain.** Each domain's **Mail** page has an
  "Enable mail" button. That one click: generates a 2048-bit DKIM key,
  and adds MX, SPF, and DKIM DNS records automatically. From there,
  add mailboxes and aliases from the same page.
- **No separate mail database to keep in sync.** Postfix and Dovecot
  query `hostpanel.db` - the same SQLite file the panel itself writes to
  - via their built-in SQLite map/driver support. Create a mailbox in
  the panel and it can receive mail immediately; no config regeneration,
  no service restart.
- **Mailbox passwords** are hashed with salted SHA-256 (`{SSHA256}`,
  computed in pure Python - Dovecot verifies this scheme natively)
  before they ever touch disk.
- **Mail storage is isolated from web content.** Mailboxes live under
  `/var/mail/vhosts/<domain>/<user>/Maildir`, owned by a single
  dedicated `vmail` account - a compromised website on the same domain
  cannot read its own domain's mailboxes, because the web vhost's Linux
  user has no access to that path.
- **Webmail** (Roundcube) is deployed the same way a hosted domain is:
  its own Linux system user, its own PHP-FPM pool, `open_basedir`-locked
  to its own directory. Reachable at `https://<panel-host>:8443/webmail`.

Before trusting it in production, verify:
```bash
dovecot -n                          # confirm SQL auth loaded without errors
postfix check && postconf -n | grep virtual_
dig TXT default._domainkey.yourdomain.com   # should match the panel's DNS page
```
And make sure your domain's registrar actually delegates to this
server's `ns1.`/`ns2.` records (shown on the domain's DNS page) - DNS
won't resolve publicly until it does.

## Stage 3: FTP + per-domain databases

```bash
bash installer/install_stage3.sh
```

Independent of Stage 2 - run it before or after. Installs ProFTPD and
adds a MariaDB client library to the panel's own virtualenv.

- **FTP reuses the identity Stage 1 already created.** The moment you
  add a domain, it gets a "primary" FTP account with the same username,
  uid, and gid as its Linux system user - you just set a password for it
  on the domain's **FTP** page. There's no second permission model to
  keep in sync with the first.
- **Scoped sub-accounts** let you hand someone (a developer, a
  freelancer) access to just one folder inside a vhost - e.g. a theme
  directory - without giving them the whole site. They share the
  domain's uid/gid, so file ownership on disk is unaffected; ProFTPD
  just chroots them to a narrower home directory, and the panel
  independently validates that directory can't escape the vhost before
  ever handing it to ProFTPD.
- **FTP is FTPS-only** (explicit TLS required, plaintext refused),
  using the same certificate as the panel and mail.
- **Same "one source of truth" pattern as Stage 2's mail:** ProFTPD
  authenticates straight against `hostpanel.db` via its own SQLite
  support - no separate account store.
- **Per-domain databases:** one click creates a MariaDB database plus a
  dedicated user that can only see that database, reachable from
  localhost only. Unlike every other credential in this app, the
  database password is stored retrievably (not hashed) - you need it
  again to paste into `wp-config.php` or similar, and that tradeoff is
  called out explicitly in `database_manager.py`.
- Every database name/username is validated against a strict whitelist
  before it's interpolated into SQL (MySQL doesn't support parameterized
  identifiers), which is what stands between a bad label and SQL
  injection into a root-level database connection - covered by tests
  before this shipped.

Before trusting it in production, verify:
```bash
proftpd -t -c /etc/proftpd/proftpd.conf
# then an actual FTPS client connection (explicit mode) against port 21
mysql -u <db_user> -p <db_name>   # using credentials from the Databases page
```

## Stage 4: Free HTTPS (Let's Encrypt)

```bash
bash installer/install_stage4.sh
```

Independent of Stages 2/3 - run it whenever.

- **One click per domain.** The domain's **SSL** page has an "Issue free
  HTTPS certificate" button. It requests a certificate from Let's
  Encrypt using an HTTP-01 challenge served straight out of the domain's
  existing `httpdocs` folder - no Apache changes needed beforehand.
- **The vhost regenerates itself.** The same `write_apache_vhost()`
  function from Stage 1 now checks whether a certificate exists on disk
  for the domain; if it does, it emits a redirect-to-HTTPS vhost on port
  80 (carving out an exception for `/.well-known/acme-challenge/` so
  future renewals keep working) plus a TLS vhost on 443 with HSTS
  enabled. Nothing else in the codebase needed to change to support
  this - it's the same generated-from-data pattern as everything else.
- **Renewal is unattended.** certbot's own systemd timer (or a
  HostPanel-provided fallback, if your mirror's certbot package doesn't
  ship one) runs `certbot renew` on its normal schedule; a deploy-hook
  reloads Apache afterward so running processes pick up the refreshed
  certificate without anyone touching the panel again.
- This closes the one place Plesk (and some competitors) has
  historically gated a security feature behind licensing tiers - here
  it's free because it's just certbot, wired in the same generated-
  from-data way as everything else in this project.

Before trusting it in production, verify:
```bash
certbot certificates
systemctl list-timers | grep certbot
curl -I https://yourdomain.com   # confirm the redirect and a valid cert
```
Issuance fails with a clear, readable error in the panel (not a silent
failure or a 500) if the domain's DNS isn't actually pointing at this
server yet or port 80 isn't reachable - both worth checking first via
the domain's DNS page.

## What's in the repo

```
app/                  FastAPI application (the panel itself)
  main.py             Routes: auth, dashboard, domain CRUD, file manager, DNS, mail, FTP, databases, settings
  security.py         Domain provisioning + the hardening sweep (Stage 1 core)
  dns_manager.py      BIND zone generation from SQLite records (Stage 2)
  mail_manager.py     Mail domain/mailbox/alias provisioning + DKIM (Stage 2)
  ftp_manager.py      FTP account provisioning, reusing the domain's own identity (Stage 3)
  database_manager.py Per-domain MariaDB database/user provisioning (Stage 3)
  tls_manager.py      Let's Encrypt certificate issuance, ties into security.write_apache_vhost() (Stage 4)
  filemanager.py       Path-contained file operations
  auth.py             Password hashing (stdlib scrypt), session helpers
  db.py               SQLite schema + lightweight migrations (admins, domains, dns_records, mail_*, ftp_accounts, databases, audit_log)
  templates/, static/  UI
installer/
  install.sh          Stage 1: AlmaLinux 10, Apache/PHP-FPM/MariaDB/panel
  install_stage2.sh   Stage 2: BIND, Postfix, Dovecot, OpenDKIM, Roundcube
  install_stage3.sh   Stage 3: ProFTPD, per-domain database support
  install_stage4.sh   Stage 4: certbot + renewal deploy-hook
systemd/                Unit files for the panel daemon + hardening timer
scripts/harden_sweep.py Entry point the timer calls every 10 minutes
```

## Roadmap (Stage 5+)

The full Plesk-equivalent feature set from the original request, plus
free TLS, is now in place. What's left is refinement:

- **Resource limits:** per-domain CPU/memory caps via systemd slices or
  cgroups, and disk quotas per Linux user (web) / mailbox (mail).
- **Mail quotas enforced**, not just recorded (`quota_mb` is currently
  stored but not yet wired into Dovecot's quota plugin).
- **Re-run-safe installers** and a proper upgrade path (schema
  migrations - `db.py` now has a small framework for this, see
  `_migrate()` - and idempotent package/service state) across all
  four stages.
- **A phpMyAdmin/Adminer-style database browser** in the panel, instead
  of only credential management.
- **Per-domain PHP version selection**, and a backup/restore feature.
- **2FA on the admin login.**
- **TLS for mail/FTP/the panel itself**, not just hosted domains - these
  currently share one self-signed certificate; wiring them to Let's
  Encrypt too needs a stable hostname decision (a dedicated panel
  subdomain) that's a policy choice for whoever runs this, not something
  to default silently.

## Known limitations to be upfront about

- Only one PHP version is used (whatever `php-fpm` on AlmaLinux 10
  ships); a per-domain PHP version selector is a future improvement.
- No built-in backup/restore yet.
- No 2FA on the admin login yet - use a strong password and don't expose
  the panel to the open internet if you can restrict it by IP/VPN instead.
- SELinux is set to a permissive-enough policy to make Apache/PHP-FPM/
  the reverse proxy work out of the box; a tighter, purpose-built SELinux
  policy module is worth building once the feature set stabilizes.
- **Stage 2 specifically:** mail and DNS use the same self-signed
  certificate as the panel - real mail clients and DNS-over-TLS resolvers
  will warn until you put a proper certificate on the box. Mailbox quotas
  are stored but not yet enforced. Dovecot's SQLite driver package name
  varies slightly by distro/mirror; if `dovecot -n` complains about the
  `sql` passdb after running `install_stage2.sh`, install whatever
  package your mirror ships it under (commonly bundled into the main
  `dovecot` package, sometimes split out) and restart Dovecot.
- **Stage 3 specifically:** same caveat applies to `proftpd-sqlite` -
  package naming for ProFTPD's SQLite backend varies by mirror; the
  installer tries the common name and tells you plainly if it couldn't
  find it. Database passwords are visible in the panel to anyone with
  admin access (by design, so they can be reused in app configs) -
  restrict panel access accordingly. There's no database browser yet,
  just credential management; use a MySQL client or your own tooling to
  work with the data itself.
- **Stage 4 specifically:** only hosted domains' web traffic gets Let's
  Encrypt certificates; the panel UI, mail (Postfix/Dovecot), and FTP
  still use the self-signed certificate from Stage 1 until you decide on
  a stable hostname for the server itself and wire that up separately.
  Certificate issuance requires port 80 to be reachable from the public
  internet for the HTTP-01 challenge - it will fail with a clear error
  (not hang or crash) if DNS isn't pointed here yet or port 80 is
  firewalled off upstream of this server.
